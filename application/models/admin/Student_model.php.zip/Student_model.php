<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Student_model extends CI_Model
{

	public function get_all_new_admission_pending_ajax($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.admission_status', '0');
		if($this->session->userdata('admin_id') == "39" || $this->session->userdata('admin_id') == "43"){ 
			$this->db->where('tbl_student.center_id', '1');
		}
		if ($this->input->post('type') != "") {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(tbl_student.created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(tbl_student.created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			//$this->db->or_like('tbl_stream.id_number',$search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$this->db->order_by('tbl_student.id', 'DESC');
		//$this->db->group_by('tbl_student.email');
		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_all_new_admission_pending_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.admission_status', '0');
		if($this->session->userdata('admin_id') == "39" || $this->session->userdata('admin_id') == "43"){ 
			$this->db->where('tbl_student.center_id', '1');
		}
		if ($this->input->post('type') != "") {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}


		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(tbl_student.created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(tbl_student.created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			//$this->db->or_like('tbl_stream.id_number',$search);

			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		//$this->db->group_by('tbl_student.email');
		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function get_student_for_enrolled()
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.admission_status', '0');

		$this->db->where('tbl_student.id', $this->uri->segment(2));

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$result = $this->db->get('tbl_student');

		return $result->row();
	}

	public function get_student_fees_for_enrolled()
	{

		$this->db->select('tbl_student_fees.*');

		$this->db->where('tbl_student_fees.is_deleted', '0');

		$this->db->where('tbl_student_fees.status', '1');

		$this->db->where('tbl_student_fees.fees_type', '1');

		//$this->db->where('tbl_student_fees.payment_status','0');

		$this->db->where('tbl_student_fees.student_id', $this->uri->segment(2));

		$result = $this->db->get('tbl_student_fees');

		return $result->row();
	}

	public function get_active_bank()
	{

		$this->db->where('is_deleted', '0');

		$this->db->order_by('bank_name', 'ASC');

		$result = $this->db->get('tbl_bank');

		return $result->result();
	}

	public function enroll_validate_password()
	{

		$exist = $this->Setting_model->get_password_setting();

		if (!empty($exist) && $exist->enrollment == $this->input->post('password')) {

			$session = array(

				'enroled_password' => '1'

			);

			$this->session->set_userdata($session);

			return true;
		} else {

			return false;
		}
	}

	public function get_unique_transaction()
	{

		if ($this->input->post('transaction_id') != "Cash") {

			$this->db->where('is_deleted', '0');

			$this->db->where('payment_status', '1');

			//$this->db->where('examination_id', '0');

			$this->db->where('id !=', $this->input->post('fees'));

			$this->db->where('transaction_id', $this->input->post('transaction_id'));

			$result = $this->db->get('tbl_student_fees');

			echo $result->num_rows();
		} else {

			echo "0";
		}
	}

	public function generate_enrollment_number()
	{

		$data = array(

			'year_sem' 			=> $this->input->post('year_sem'),

			'payment_mode' 		=> $this->input->post('payment_mode'),

			'payment_date' 		=> date("Y-m-d", strtotime($this->input->post('payment_date'))),

			'payment_status' 	=> $this->input->post('payment_status'),

			'transaction_id' 	=> $this->input->post('transaction_id'),

			'bank_id' 			=> $this->input->post('bank'),

			'late_fees' 		=> $this->input->post('late_fees'),

			'bank_fees' 		=> $this->input->post('bank_fees'),

			'amount' 			=> $this->input->post('amount'),

			'lateral_entry_fees' => $this->input->post('lateral_entry_fees'),

			'original_amount' 	=> $this->input->post('original_amount'),

			'discount' 			=> $this->input->post('discount'),

			'total_fees' 		=> $this->input->post('total_fees'),

			'remark' 			=> $this->input->post('remark'),

		);

		$this->db->where('id', $this->input->post('fees_id'));

		$this->db->update("tbl_student_fees", $data);

		$admission = array(

			'admission_status' => $this->input->post('payment_status')

		);

		$this->db->where('id', $this->input->post('student_id'));

		$this->db->update("tbl_student", $admission);

		if ($this->input->post('payment_status') == "1") {

			$this->db->where('id', $this->input->post('student_id'));

			$student_details = $this->db->get("tbl_student");

			$student_details = $student_details->row();

			$this->db->where('id', $student_details->faculty_id);

			$faculty = $this->db->get('tbl_faculty');

			$faculty = $faculty->row();

			$this->db->where('faculty', $student_details->faculty_id);

			$this->db->where('course', $student_details->course_id);

			$this->db->where('stream', $student_details->stream_id);

			$this->db->where('is_deleted', '0');

			$this->db->where('status', '1');

			$course_code = $this->db->get('tbl_course_stream_relation');

			$course_code = $course_code->row();

			$this->db->where('id', $student_details->center_id);
			$center_details = $this->db->get("tbl_center");
			$center_details = $center_details->row();

			$this->db->where('id', $student_details->faculty_id);
			$faculty = $this->db->get('tbl_faculty');
			$faculty = $faculty->row();

			$this->db->where('faculty', $student_details->faculty_id);
			$this->db->where('course', $student_details->course_id);
			$this->db->where('stream', $student_details->stream_id);
			$this->db->where('is_deleted', '0');
			$this->db->where('status', '1');
			$course_code = $this->db->get('tbl_course_stream_relation');
			$course_code = $course_code->row();

			$this->db->where('id', $student_details->session_id);
			$session_year = $this->db->get('tbl_session');
			$session_year = $session_year->row();
			
			$session_date = $lastTwoDigits1 = substr($session_year->session_name, -2);
			
			$enrollment = "";
			$enrollment .= $session_date;
			if (!empty($center_details)) {
				//$enrollment .= $center_details->center_code;
			}
			if (!empty($course_code)) {
				$enrollment .= $course_code->course_code;
			}
			
			if (!empty($faculty)) {
				//$enrollment .= $faculty->faculty_code; 
			}
			$last_digit = 10000;
			if (strlen($student_details->id) == "1") {
				$last_digit = 10000;
			}
			if (strlen($student_details->id) == "2") {
				$last_digit = 1000;
			}
			if (strlen($student_details->id) == "3") {
				$last_digit = 100;
			}
			if (strlen($student_details->id) == "4") {
				$last_digit = 10;
			}
			if (strlen($student_details->id) == "5") {
				$last_digit = 1;
			}
			if (strlen($student_details->id) == "6") {
				$last_digit = "";
			}
			$enrollment .= $last_digit . $student_details->id;


			$enorlled_data = array(

				'admission_status' 	=> $this->input->post('payment_status'),

				'enrollment_number' => $enrollment,

				'enrollment_date' 	=> date("Y-m-d"),

			);

			$this->db->where('id', $this->input->post('student_id'));

			$this->db->update("tbl_student", $enorlled_data);

			$this->db->where('id', $this->input->post('student_id'));

			$student_data = $this->db->get("tbl_student");

			$student_data = $student_data->row();

			$sms_message = "Dear " . $this->input->post('student_name') . ",\n Your Admission has been confirmed, below are the login details of your account\n Username:" . $student_data->username . "\nPassword:" . $student_data->password;

			//$mail_message = "Dear ".$this->input->post('student_name').",<br> Your Admission has been confirmed, below are the login details of your account<br> Username:".$student_data->username."<br>Password:".$student_data->password;

			$mail_message = '

			<!DOCTYPE html>

                <html>

                    <head>

                        <title></title>

                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

                        <meta name="viewport" content="width=device-width, initial-scale=1">

                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

                        <style type="text/css">

                            @media screen {

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 400;

                                    src: local("Lato Regular"), local("Lato-Regular"), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 700;

                                    src: local("Lato Bold"), local("Lato-Bold"), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family:  "Lato";

                                    font-style: italic;

                                    font-weight: 400;

                                    src: local("Lato Italic"), local("Lato-Italic"), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: v

                                    font-style: italic;

                                    font-weight: 700;

                                    src: local("Lato Bold Italic"), local("Lato-BoldItalic"), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format("woff");

                                }

                            }

                    

                            /* CLIENT-SPECIFIC STYLES */

                            body,

                            table,

                            td,

                            a {

                                -webkit-text-size-adjust: 100%;

                                -ms-text-size-adjust: 100%;

                            }

                    

                            table,

                            td {

                                mso-table-lspace: 0pt;

                                mso-table-rspace: 0pt;

                            }

                    

                            img {

                                -ms-interpolation-mode: bicubic;

                            }

                    

                            /* RESET STYLES */

                            img {

                                border: 0;

                                height: auto;

                                line-height: 100%;

                                outline: none;

                                text-decoration: none;

                            }

                    

                            table {

                                border-collapse: collapse !important;

                            }

                    

                            body {

                                height: 100% !important;

                                margin: 0 !important;

                                padding: 0 !important;

                                width: 100% !important;

                            }

                    

                            /* iOS BLUE LINKS */

                            a[x-apple-data-detectors] {

                                color: inherit !important;

                                text-decoration: none !important;

                                font-size: inherit !important;

                                font-family: inherit !important;

                                font-weight: inherit !important;

                                line-height: inherit !important;

                            }

                    

                            /* MOBILE STYLES */

                            @media screen and (max-width:600px) {

                                h1 {

                                    font-size: 32px !important;

                                    line-height: 32px !important;

                                }

                            }

                    

                            /* ANDROID CENTER FIX */

                            div[style*="margin: 16px 0;"] {

                                margin: 0 !important;

                            }

                        </style>

                    </head> 

                    <body style="background-color: #f4f4f4; margin: 0 !important; padding: 0 !important;">
    <table border="0" cellpadding="0" cellspacing="0" width="100%">

        <!-- LOGO -->
        <tr>
            <td bgcolor="#FFA73B" align="center">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td align="center" valign="top" style="padding: 40px 10px 40px 10px;"> </td>
                    </tr>
                </table>
            </td>
        </tr>

        <tr>

            <td bgcolor="#FFA73B" align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>
                        <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
                            <h1 style="font-size: 35px; font-weight: 400; margin: 2;">Admission confirmed!</h1>
							<img src="' . $this->Digitalocean_model->get_photo('images/logo/ok.png') . '" width="125" height="120" style="display: block; border: 0px;" />				
                        </td>

                    </tr>

                </table>

            </td>

        </tr>

        <tr>

            <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

                            <p style="margin: 0;">Dear ' . $this->input->post('student_name') . ',<br><br> Your Admission has been confirmed, below are the Login Details of your account :<br><br>URL:' . base_url() . 'student-corner/' . '<br> Username:' . $student_data->username . '<br>Password:' . $student_data->password . '</p>

                            <br>
                        </td>

                    </tr>
                    <tr>

                        <td bgcolor="#ffffff" align="left" style="padding: 0px 30px 40px 30px; border-radius: 0px 0px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

                            <p style="margin: 0;">Best Regards,<br>IT Team</p>

                        </td>

                    </tr>

                </table>

            </td>

        </tr>

    </table>

</body>



</html>

			';


			// <img src="'.base_url().'assets/images/ok.png" width="125" height="120" style="display: block; border: 0px;" />
			// <div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family: "Lato", Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;"> We are thrilled to have you here! Get ready to drive into your new account.

			// </div>

			// 	<tr>

			// 	<td bgcolor="#ffffff" align="left" style="padding: 0px 30px 20px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

			// 		<p style="margin: 0;">If you have any questions, just reply to this email info@theglobaluniversity.edu.in we are always happy to help out.</p>

			// 	</td>

			// </tr>


			// <tr>

			//     <td bgcolor="#f4f4f4" align="center" style="padding: 30px 10px 0px 10px;">

			//         <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

			//             <tr>

			//                 <td bgcolor="#FFECD1" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

			//                     <h2 style="font-size: 20px; font-weight: 400; color: #111111; margin: 0;">Need more help?</h2>

			//                     <p style="margin: 0;"><a href="'.base_url().'contact-us" target="_blank" style="color: #FFA73B;">We&rsquo;re here to help you out</a></p>

			//                 </td>

			//             </tr>

			//         </table>

			//     </td>

			// </tr>


			$this->send_common_sms($student_data->mobile, $sms_message);

			$this->load->library('email');

			$config['protocol'] = 'sendmail';

			$config['mailpath'] = '/usr/sbin/sendmail';

			$config['mailtype'] = 'html';

			$config['charset'] = 'iso-8859-1';

			$config['wordwrap'] = TRUE;

			$this->email->initialize($config);

			$this->email->from(no_reply_mail);

			$this->email->to($student_data->email);

			$this->email->subject('New Password |' . no_reply_name);

			$this->email->set_mailtype('html');

			$message = $mail_message;

			// $message .="<br>Best Regards<br>IT Team";

			// print_r($message);exit;

			$this->email->message($message);

			if ($this->email->send()) {
			} else {
			}

			redirect('print_admission_form/' . $student_data->id);
		} else {

			return false;
		}
	}
	public function send_common_sms($mobile_number, $msg)
	{

		$authKey = SMSKEY;

		$senderId = SENDERID;

		$route = ROUTE;

		$message = $msg;

		$postData = array(

			'authkey' => $authKey,

			'mobiles' => $mobile_number,

			'message' => $message,

			'sender' => $senderId,

			'route' => $route

		);

		$url = "http://sms.bulksmsserviceproviders.com/api/send_http.php";

		$ch = curl_init();

		curl_setopt_array($ch, array(

			CURLOPT_URL => $url,

			CURLOPT_RETURNTRANSFER => true,

			CURLOPT_POST => true,

			CURLOPT_POSTFIELDS => $postData

		));

		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

		$output = curl_exec($ch);

		if (curl_errno($ch)) {

			echo 'error:' . curl_error($ch);
		}

		curl_close($ch);

		return true;
	}
	public function get_admission_form()
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_course.print_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');
		$this->db->where('tbl_student.is_deleted', '0');
		//$this->db->where('tbl_student.admission_status !=','0');
		$this->db->where('tbl_student.id', $this->uri->segment(2));
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');
		$this->db->join('countries', 'countries.id = tbl_student.country');
		$this->db->join('states', 'states.id = tbl_student.state');
		$this->db->join('cities', 'cities.id = tbl_student.city');
		$result = $this->db->get('tbl_student');
		return $result->row();
	}
	public function get_admission_qualification()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('student_id', $this->uri->segment(2));
		$result = $this->db->get('tbl_student_qualification');
		return $result->row();
	}
	public function get_all_admission_ajax($length, $start, $search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.verified_status', '1');
		// $this->db->where('tbl_student.verified_status','1');
		$this->db->where('tbl_student.course_for', '0');
		if($this->session->userdata('admin_id') == "39" || $this->session->userdata('admin_id') == "43"){ 
			$this->db->where('tbl_student.center_id', '1');
		}
		if ($this->input->post('type') != "") {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		// $this->db->where('tbl_student.admission_status !=','0');
		// $this->db->where('tbl_student.admission_status !=','2');
		$this->db->where('tbl_student.admission_status', '1');

		if ($this->input->post('start_date') != "") {
			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}
		if ($this->input->post('end_date') != "") {
			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}
		if ($this->input->post('session') != "") {
			$this->db->where('tbl_student.session_id', $this->input->post('session'));
		}
		if ($this->input->post('center') != "") {
			$this->db->where('tbl_student.center_id', $this->input->post('center'));
		}
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);
			$this->db->or_like('tbl_center.center_name', $search);
			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->or_like('tbl_student.religion', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.enrollment_date', 'DESC');
		$this->db->limit($length, $start);
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->result();
	}
	public function get_all_admission_count($search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.verified_status', '1');
		$this->db->where('tbl_student.course_for', '0');
		// $this->db->where('tbl_student.admission_status !=','0');
		// $this->db->where('tbl_student.admission_status !=','2');
		if($this->session->userdata('admin_id') == "39" || $this->session->userdata('admin_id') == "43"){ 
			$this->db->where('tbl_student.center_id', '1');
		}
		
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}
		$this->db->where('tbl_student.admission_status', '1');

		if ($this->input->post('start_date') != "") {
			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}
		if ($this->input->post('end_date') != "") {
			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}
		if ($this->input->post('session') != "") {
			$this->db->where('tbl_student.session_id', $this->input->post('session'));
		}
		if ($this->input->post('center') != "") {
			$this->db->where('tbl_student.center_id', $this->input->post('center'));
		}
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);
			$this->db->or_like('tbl_center.center_name', $search);
			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->or_like('tbl_student.religion', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.id', 'ASC');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->num_rows();
	}
	public function get_new_admission_list_ajax($length, $start, $search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.verified_status', '0');
		$this->db->where('tbl_student.admission_status', '1');
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}
		if ($this->input->post('start_date') != "") {
			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}
		if ($this->input->post('end_date') != "") {
			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);
			$this->db->or_like('tbl_center.center_name', $search);
			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.enrollment_date', 'DESC');
		$this->db->limit($length, $start);
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id', 'left');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id', 'left');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type', 'left');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id', 'left');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id', 'left');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id', 'left');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type', 'left');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->result();
	}
	public function get_new_admission_list_ajax_count($search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.verified_status', '0');
		$this->db->where('tbl_student.admission_status', '1');
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($this->input->post('start_date') != "") {
			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}
		if ($this->input->post('end_date') != "") {
			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);
			$this->db->or_like('tbl_center.center_name', $search);
			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.id', 'ASC');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type', 'left');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id', 'left');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id', 'left');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id', 'left');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id', 'left');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type', 'left');
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id', 'left');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->num_rows();
	}




	public function get_new_admission_list_from_external($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name,tbl_verification_user_login.name as verified_by,tbl_verification_user_login.name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.doc_verify', '1');

		//$this->db->where('tbl_student.admission_status !=','0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_verification_user_login.name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.doc_verified_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$this->db->join('tbl_verification_user_login', 'tbl_verification_user_login.id = tbl_student.doc_verified_by');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_new_admission_list_from_external_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name,tbl_verification_user_login.name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.doc_verify', '1');

		//$this->db->where('tbl_student.admission_status !=','0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_verification_user_login.name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.doc_verified_date', 'DESC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$this->db->join('tbl_verification_user_login', 'tbl_verification_user_login.id = tbl_student.doc_verified_by');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function get_new_admission_rejected_list_from_external($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name,tbl_verification_user_login.name as verified_by');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.doc_verify', '2');

		$this->db->where('tbl_student.admission_status !=', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.enrollment_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$this->db->join('tbl_verification_user_login', 'tbl_verification_user_login.id = tbl_student.doc_verified_by');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_new_admission_rejected_list_from_external_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.doc_verify', '2');

		$this->db->where('tbl_student.admission_status !=', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}



	public function get_today_admission_list_ajax($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name,tbl_employees.first_name,tbl_employees.last_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.verified_date', date("Y-m-d"));

		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);   //---

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_employees.first_name', $search);

			$this->db->or_like('tbl_employees.last_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.enrollment_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student.verified_by');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_today_admission_list_ajax_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name,tbl_employees.first_name,tbl_employees.last_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.verified_date', date("Y-m-d"));

		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_employees.first_name', $search);

			$this->db->or_like('tbl_employees.last_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student.verified_by');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function approved_admission()
	{

		$data = array(

			'verified_status' => '1',

			'verified_by' => $this->session->userdata('admin_id'),

			'verified_date' => date("Y-m-d"),

		);

		$this->db->where('id', $this->uri->segment(2));

		$this->db->update('tbl_student', $data);
		$this->db->where('id', $this->uri->segment(2));
		$result = $this->db->get('tbl_student');

		$result = $result->row();

		$profile = $this->Admin_model->get_profile();

		$log_description = $profile->first_name . " " . $profile->last_name . " has approved admission of " . $result->student_name . " (" . $result->id . ")" . " on " . date("d/m/Y");

		$log = array(

			'user_id' 		=> $this->session->userdata('admin_id'),

			'student_id' 	=> $result->id,

			'description' 	=> $log_description,

			'date' 			=> date("Y-m-d"),

			'created_on' 	=> date("Y-m-d H:i:s"),

		);

		$this->Setting_model->set_log($log);

		$this->load->library('email');

		$config['protocol'] = 'sendmail';

		$config['mailpath'] = '/usr/sbin/sendmail';

		$config['mailtype'] = 'html';

		$config['charset'] = 'iso-8859-1';

		$config['wordwrap'] = TRUE;

		$this->email->initialize($config);

		/*	$this->load->library('email');  

		$config = array();  

		$config['protocol'] = 'smtp';  

		$config['smtp_host'] = '166.62.26.44';  

		$config['smtp_user'] = 'no-reply@tgu.com';  

		$config['smtp_pass'] = 'no-reply@123';  

		$config['smtp_port'] = 25;

		$this->email->initialize($config);  

      */

		$message = "Dear " . $result->student_name . ",";

		$message .= "<br><br>I hope this email finds you well. This email is to inform you that the document approval process for your recent admission has been successfully completed.
		<br> thank you for your cooperation throughout the approval process.<br>Once again, congratulations on the successful completion of the admission process.<br>";

		// $message .= "<br>Username: ".$result->username;

		// $message .= "<br>Password: ".$result->password;

		$message .= "<br><br><b>Best Regards,</b><br> IT Team ";

		$subject = "Document Approval Process Successfully Completed |" . no_reply_name;

		$this->email->message($message);

		$to = array(

			"email" => $result->email,

			"name" => $result->student_name,

		);

		// $subject = 'Admission Approved | Global University';    

		$this->Admin_model->send_send_blue($to, $subject, $message);

		return true;
	}

	public function get_single_student()
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.id', $this->uri->segment(2));

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');

		$this->db->join('states', 'states.id = tbl_student.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');

		$result = $this->db->get('tbl_student');

		return $result->row();
	}



	public function get_otp_lead_list($length, $start, $search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_registration_lead');

		return $result->result();
	}

	public function get_otp_lead_list_count($search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$result = $this->db->get('tbl_registration_lead');

		return $result->num_rows();
	}

	public function get_enquiry_list($length, $start, $search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->or_like('query', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_enquery');

		return $result->result();
	}

	public function get_enquiry_list_count($search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->or_like('query', $search);

			$this->db->group_end();
		}

		$result = $this->db->get('tbl_enquery');

		return $result->num_rows();
	}





	public function get_admin_campus_enquiry($length, $start, $search)
	{

		$this->db->select('tbl_campus_enquery.*,tbl_followup_heads.head_name');

		$this->db->where('tbl_campus_enquery.is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(tbl_campus_enquery.created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(tbl_campus_enquery.created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_followup_heads.head_name', $search);

			$this->db->or_like('tbl_campus_enquery.mobile_number', $search);

			$this->db->or_like('tbl_campus_enquery.email', $search);

			$this->db->or_like('tbl_campus_enquery.name', $search);

			$this->db->or_like('tbl_campus_enquery.father_name', $search);

			$this->db->or_like('tbl_campus_enquery.mother_name', $search);

			$this->db->or_like('tbl_campus_enquery.address', $search);

			$this->db->or_like('tbl_campus_enquery.course', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_followup_heads', 'tbl_followup_heads.id = tbl_campus_enquery.head_id');

		$result = $this->db->get('tbl_campus_enquery');

		return $result->result();
	}

	public function get_admin_campus_enquiry_count($search)
	{

		$this->db->select('tbl_campus_enquery.*,tbl_followup_heads.head_name');

		$this->db->where('tbl_campus_enquery.is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(tbl_campus_enquery.created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(v.created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_followup_heads.head_name', $search);

			$this->db->or_like('tbl_campus_enquery.mobile_number', $search);

			$this->db->or_like('tbl_campus_enquery.email', $search);

			$this->db->or_like('tbl_campus_enquery.name', $search);

			$this->db->or_like('tbl_campus_enquery.father_name', $search);

			$this->db->or_like('tbl_campus_enquery.mother_name', $search);

			$this->db->or_like('tbl_campus_enquery.address', $search);

			$this->db->or_like('tbl_campus_enquery.course', $search);

			$this->db->group_end();
		}

		$this->db->join('tbl_followup_heads', 'tbl_followup_heads.id = tbl_campus_enquery.head_id');

		$result = $this->db->get('tbl_campus_enquery');

		return $result->num_rows();
	}



	public function get_pulp_enquiry_list($length, $start, $search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->or_like('location', $search);

			$this->db->or_like('course', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_pulp_enquiry');

		return $result->result();
	}

	public function get_pulp_enquiry_list_count($search)
	{

		$this->db->where('is_deleted', '0');

		if ($this->input->post('start_date') != "") {

			$this->db->where('Date(created_on) >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('Date(created_on) <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('mobile', $search);

			$this->db->or_like('email', $search);

			$this->db->or_like('name', $search);

			$this->db->or_like('location', $search);

			$this->db->or_like('course', $search);

			$this->db->group_end();
		}

		$result = $this->db->get('tbl_pulp_enquiry');

		return $result->num_rows();
	}

	public function get_all_phd_registration_successfully($length, $start, $search)
	{
		$this->db->select('tbl_phd_registration_form.*,tbl_course.print_name as course_name,tbl_stream.stream_name,countries.name as country_name,states.name as state_name,cities.name as city_name');
		$this->db->where('tbl_phd_registration_form.is_deleted', '0');
		$this->db->where('tbl_phd_registration_form.payment_status', '1');
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_phd_registration_form.student_name', $search);
			$this->db->or_like('tbl_phd_registration_form.father_name', $search);
			$this->db->or_like('tbl_phd_registration_form.mother_name', $search);
			$this->db->or_like('tbl_phd_registration_form.mobile_number', $search);
			$this->db->or_like('tbl_phd_registration_form.email_id', $search);

			$this->db->or_like('tbl_phd_registration_form.category', $search);
			$this->db->or_like('tbl_phd_registration_form.current_address', $search);
			$this->db->or_like('tbl_phd_registration_form.amount', $search);
			$this->db->or_like('tbl_phd_registration_form.payment_id', $search);
			$this->db->or_like('tbl_phd_registration_form.employment_details', $search);

			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_course.print_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_phd_registration_form.id', 'DESC');
		$this->db->limit($length, $start);
		$this->db->join('tbl_course', 'tbl_course.id = tbl_phd_registration_form.course');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_phd_registration_form.stream');
		$this->db->join('countries', 'countries.id = tbl_phd_registration_form.country');
		$this->db->join('states', 'states.id = tbl_phd_registration_form.state');
		$this->db->join('cities', 'cities.id = tbl_phd_registration_form.city');

		$result = $this->db->get('tbl_phd_registration_form');
		return $result->result();
	}
	public function get_all_phd_registration_successfully_count($search)
	{
		$this->db->select('tbl_phd_registration_form.*,tbl_course.print_name as course_name,tbl_stream.stream_name,countries.name as country_name,states.name as state_name,cities.name as city_name');
		$this->db->where('tbl_phd_registration_form.is_deleted', '0');
		$this->db->where('tbl_phd_registration_form.payment_status', '1');
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_phd_registration_form.student_name', $search);
			$this->db->or_like('tbl_phd_registration_form.father_name', $search);
			$this->db->or_like('tbl_phd_registration_form.mother_name', $search);
			$this->db->or_like('tbl_phd_registration_form.mobile_number', $search);
			$this->db->or_like('tbl_phd_registration_form.email_id', $search);

			$this->db->or_like('tbl_phd_registration_form.category', $search);
			$this->db->or_like('tbl_phd_registration_form.current_address', $search);
			$this->db->or_like('tbl_phd_registration_form.amount', $search);
			$this->db->or_like('tbl_phd_registration_form.payment_id', $search);
			$this->db->or_like('tbl_phd_registration_form.employment_details', $search);

			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_course.print_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_phd_registration_form.id', 'ASC');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_phd_registration_form.course');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_phd_registration_form.stream');
		$this->db->join('countries', 'countries.id = tbl_phd_registration_form.country');
		$this->db->join('states', 'states.id = tbl_phd_registration_form.state');
		$this->db->join('cities', 'cities.id = tbl_phd_registration_form.city');
		$result = $this->db->get('tbl_phd_registration_form');
		return $result->num_rows();
	}

	public function get_all_phd_registration_failed($length, $start, $search)
	{

		$this->db->select('tbl_phd_registration_form.*,tbl_course.print_name as course_name,tbl_stream.stream_name,countries.name as country_name,states.name as state_name,cities.name as city_name');

		$this->db->where('tbl_phd_registration_form.is_deleted', '0');

		$this->db->where('tbl_phd_registration_form.payment_status', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_phd_registration_form.student_name', $search);

			$this->db->or_like('tbl_phd_registration_form.father_name', $search);

			$this->db->or_like('tbl_phd_registration_form.mother_name', $search);

			$this->db->or_like('tbl_phd_registration_form.mobile_number', $search);

			$this->db->or_like('tbl_phd_registration_form.email_id', $search);

			$this->db->or_like('tbl_phd_registration_form.current_address', $search);

			$this->db->or_like('tbl_phd_registration_form.employment_details', $search);

			$this->db->or_like('tbl_phd_registration_form.amount', $search);

			$this->db->or_like('tbl_phd_registration_form.payment_id', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_course.print_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_phd_registration_form.id', 'DESC');

		$this->db->group_by('tbl_phd_registration_form.mobile_number');

		$this->db->limit($length, $start);


		$this->db->join('tbl_course', 'tbl_course.id = tbl_phd_registration_form.course', 'left');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_phd_registration_form.stream', 'left');

		$this->db->join('countries', 'countries.id = tbl_phd_registration_form.country', 'left');

		$this->db->join('states', 'states.id = tbl_phd_registration_form.state', 'left');

		$this->db->join('cities', 'cities.id = tbl_phd_registration_form.city', 'left');

		$result = $this->db->get('tbl_phd_registration_form');

		return $result->result();
		// $result = $result->result();	
		// echo "<pre>";print_r($result);exit;
	}

	public function get_all_phd_registration_failed_count($search)
	{

		$this->db->select('tbl_phd_registration_form.*,tbl_course.print_name as course_name,tbl_stream.stream_name,countries.name as country_name,states.name as state_name,cities.name as city_name');

		$this->db->where('tbl_phd_registration_form.is_deleted', '0');

		$this->db->where('tbl_phd_registration_form.payment_status', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_phd_registration_form.student_name', $search);

			$this->db->or_like('tbl_phd_registration_form.father_name', $search);

			$this->db->or_like('tbl_phd_registration_form.mother_name', $search);

			$this->db->or_like('tbl_phd_registration_form.mobile_number', $search);

			$this->db->or_like('tbl_phd_registration_form.email_id', $search);

			$this->db->or_like('tbl_phd_registration_form.current_address', $search);

			$this->db->or_like('tbl_phd_registration_form.employment_details', $search);

			$this->db->or_like('tbl_phd_registration_form.amount', $search);

			$this->db->or_like('tbl_phd_registration_form.payment_id', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_course.print_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_phd_registration_form.id', 'ASC');

		$this->db->group_by('tbl_phd_registration_form.mobile_number');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_phd_registration_form.course');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_phd_registration_form.stream');

		$this->db->join('countries', 'countries.id = tbl_phd_registration_form.country');

		$this->db->join('states', 'states.id = tbl_phd_registration_form.state');

		$this->db->join('cities', 'cities.id = tbl_phd_registration_form.city');

		$result = $this->db->get('tbl_phd_registration_form');

		return $result->num_rows();
	}

	public function get_failed_phd_single()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('id', $this->uri->segment(2));

		$result = $this->db->get('tbl_phd_registration_form');

		return $result->row();
		// $result = $result->row();
		// echo "<pre>";print_r($result);exit;
	}

	public function get_unique_phd_payment()
	{

		$this->db->where('id !=', $this->input->post('id'));

		$this->db->where('payment_id', $this->input->post('payment_id'));

		$result = $this->db->get('tbl_phd_registration_form');

		echo $result->num_rows();
	}
	public function get_center_list()
	{
		$this->db->where('is_deleted', '0');
		$this->db->order_by('center_name', 'ASC');
		$result = $this->db->get('tbl_center');
		return $result->result();
	}

	public function set_update_phd_payment()
	{

		$data = array(
			'student_name' 			=> $this->input->post('student_name'),
			'email_id' 			=> $this->input->post('email'),

			'mobile_number' 	=> $this->input->post('mobile'),

			'stream' 			=> $this->input->post('stream'),

			'payment_id' 		=> $this->input->post('payment_id'),

			'payment_status' 	=> $this->input->post('payment_status'),

			'amount' 			=> $this->input->post('fees'),

			'payment_date' 		=> date("Y-m-d", strtotime($this->input->post('payment_date'))),

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_phd_registration_form', $data);

		return true;
	}

	public function get_phd_exam_student()
	{
		// echo "<pre>";print_r($this->uri->segment(2));exit;
		$this->db->select('tbl_phd_registration_form.*,tbl_phd_ent_scores.created_on,tbl_phd_ent_scores.score,tbl_phd_ent_scores.id as student_exam_id,tbl_phd_ent_scores.test_id,tbl_phd_ent_scores.created_on as date_of_exam,tbl_test_title_for_phd.test_name');
		$this->db->where('tbl_phd_registration_form.payment_status', '1');
		$this->db->where('tbl_phd_ent_scores.is_deleted', '0');
		$this->db->join('tbl_test_title_for_phd', 'tbl_test_title_for_phd.id = tbl_phd_ent_scores.test_id');
		$this->db->join('tbl_phd_registration_form', 'tbl_phd_registration_form.email_id = tbl_phd_ent_scores.student_email');
		$this->db->order_by('tbl_phd_ent_scores.id', 'DESC');
		// $this->db->group_by('tbl_phd_ent_scores.student_email');
		// $this->db->group_by('tbl_phd_registration_form.email_id');
		$result = $this->db->get('tbl_phd_ent_scores');
		return $result->result();
		// $result = $result->result();
		// echo "<pre>";print_r($result);exit;
	}

	public function update_student($identity_softcopy, $photo, $noc, $signature, $secondary_marksheet, $sr_secondary_marksheet, $graduation_marksheet, $post_graduation_marksheet, $other_qualification_marksheet, $permission_letter, $ohter_files, $undertaking)
	{
		$this->db->where('id', $this->input->post('student_id'));

		$student_row = $this->db->get('tbl_student');

		$student_row = $student_row->row();

		$profile = $this->Admin_model->get_profile();

		$add_log = 1;

		$log_description = $profile->first_name . " " . $profile->last_name . " has updated below details of " . $student_row->student_name . " (" . $student_row->id . ")" . " on " . date("d/m/Y");

		if ($student_row->student_name != $this->input->post('student_name')) {

			$add_log = 0;

			$log_description .= "<br>Student name " . $student_row->student_name . " to " . $this->input->post('student_name');
		}

		if ($student_row->admission_date != date("Y-m-d", strtotime($this->input->post('admission_date')))) {

			$add_log = 0;

			$log_description .= "<br>Registration date " . $student_row->admission_date . " to " . date("Y-m-d", strtotime($this->input->post('admission_date')));
		}

		if ($student_row->gender != $this->input->post('gender')) {

			$add_log = 0;

			$log_description .= "<br>Gender " . $student_row->gender . " to " . $this->input->post('gender');
		}

		if ($student_row->father_name != $this->input->post('father_name')) {

			$add_log = 0;

			$log_description .= "<br>Father name " . $student_row->father_name . " to " . $this->input->post('father_name');
		}

		if ($student_row->mother_name != $this->input->post('mother_name')) {

			$add_log = 0;

			$log_description .= "<br>Mother name " . $student_row->mother_name . " to " . $this->input->post('mother_name');
		}

		if ($student_row->date_of_birth != date("Y-m-d", strtotime($this->input->post('date_of_birth')))) {

			$add_log = 0;

			$log_description .= "<br>Date of birth " . date("d-m-Y", strtotime($student_row->date_of_birth)) . " to " . $this->input->post('date_of_birth');
		}

		if ($student_row->mobile != $this->input->post('mobile')) {

			$add_log = 0;

			$log_description .= "<br>Mobile Number " . $student_row->mobile . " to " . $this->input->post('mobile');
		}

		if ($student_row->email != $this->input->post('email')) {

			$add_log = 0;

			$log_description .= "<br>Email " . $student_row->email . " to " . $this->input->post('email');
		}

		if ($student_row->pincode != $this->input->post('pincode')) {

			$add_log = 0;

			$log_description .= "<br>Pincode " . $student_row->pincode . " to " . $this->input->post('pincode');
		}

		if ($student_row->year_sem != $this->input->post('year_sem')) {

			$add_log = 0;

			$log_description .= "<br>Year/Sem " . $student_row->year_sem . " to " . $this->input->post('year_sem');
		}

		if ($student_row->course_mode != $this->input->post('course_mode')) {

			$add_log = 0;

			$log_description .= "<br>Course Mode " . $student_row->course_mode . " to " . $this->input->post('course_mode');
		}

		if ($student_row->address != $this->input->post('address')) {

			$add_log = 0;

			$log_description .= "<br>Address " . $student_row->address . " to " . $this->input->post('address');
		}

		if ($student_row->course_id != $this->input->post('course')) {

			$add_log = 0;

			$this->db->where('id', $student_row->course_id);

			$old_course = $this->db->get('tbl_course');

			$old_course = $old_course->row();



			$this->db->where('id', $this->input->post('course'));

			$new_course = $this->db->get('tbl_course');

			$new_course = $new_course->row();



			$log_description .= "<br>Course " . $old_course->print_name . " to " . $new_course->print_name;
		}

		if ($student_row->course_update_reason != $this->input->post('course_update_reason')) {

			$add_log = 0;

			$log_description .= "<br>Course change reason " . $student_row->course_update_reason . " to " . $this->input->post('course_update_reason');
		}

		if ($student_row->stream_id != $this->input->post('stream')) {

			$add_log = 0;

			$this->db->where('id', $student_row->stream_id);

			$old_stream = $this->db->get('tbl_stream');

			$old_stream = $old_stream->row();



			$this->db->where('id', $this->input->post('stream'));

			$new_stream = $this->db->get('tbl_stream');

			$new_stream = $new_stream->row();

			$log_description .= "<br>Stream " . $old_stream->stream_name . " to " . $new_stream->stream_name;
		}

		if ($student_row->country != $this->input->post('country')) {

			$add_log = 0;

			$this->db->where('id', $student_row->country);

			$old_data = $this->db->get('countries');

			$old_data = $old_data->row();



			$this->db->where('id', $this->input->post('country'));

			$new_data = $this->db->get('countries');

			$new_data = $new_data->row();

			$log_description .= "<br>Country " . $old_stream->name . " to " . $new_data->name;
		}

		if ($student_row->state != $this->input->post('state')) {

			$add_log = 0;

			$this->db->where('id', $student_row->state);

			$old_data = $this->db->get('states');

			$old_data = $old_data->row();



			$this->db->where('id', $this->input->post('state'));

			$new_data = $this->db->get('states');

			$new_data = $new_data->row();

			$log_description .= "<br>State " . $old_stream->name . " to " . $new_data->name;
		}

		if ($student_row->city != $this->input->post('city')) {

			$add_log = 0;

			$this->db->where('id', $student_row->city);

			$old_data = $this->db->get('cities');

			$old_data = $old_data->row();



			$this->db->where('id', $this->input->post('city'));

			$new_data = $this->db->get('cities');

			$new_data = $new_data->row();

			$log_description .= "<br>City " . $old_stream->name . " to " . $new_data->name;
		}

		if ($add_log == 0) {

			$log = array(

				'user_id' 		=> $this->session->userdata('admin_id'),

				'student_id' 	=> $student_row->id,

				'description' 	=> $log_description,

				'date' 			=> date("Y-m-d"),

				'created_on' 	=> date("Y-m-d H:i:s"),

			);

			$this->Setting_model->set_log($log);
		}

		$add_log = 1;

		$log_description = "";

		$this->db->where('student_id', $this->input->post('student_id'));

		$old_qual = $this->db->get('tbl_student_qualification');

		$old_qual = $old_qual->row();

		if (!empty($old_qual)) {

			$log_description = $profile->first_name . " " . $profile->last_name . " has updated qualification details of " . $student_row->student_name . " (" . $student_row->id . ")" . " on " . date("d/m/Y");

			if ($old_qual->secondary_year != $this->input->post('secondary_year')) {

				$add_log = 0;

				$log_description .= "<br>Secondary year " . $old_qual->secondary_year . " to " . $this->input->post('secondary_year');
			}

			if ($old_qual->secondary_university != $this->input->post('secondary_university')) {

				$add_log = 0;

				$log_description .= "<br>Secondary University " . $old_qual->secondary_university . " to " . $this->input->post('secondary_university');
			}

			if ($old_qual->secondary_marks != $this->input->post('secondary_marks')) {

				$add_log = 0;

				$log_description .= "<br>Secondary Marks " . $old_qual->secondary_marks . " to " . $this->input->post('secondary_marks');
			}

			if ($old_qual->sr_secondary_year != $this->input->post('sr_secondary_year')) {

				$add_log = 0;

				$log_description .= "<br>Sr. Secondary Year " . $old_qual->sr_secondary_year . " to " . $this->input->post('sr_secondary_year');
			}

			if ($old_qual->sr_secondary_university != $this->input->post('sr_secondary_university')) {

				$add_log = 0;

				$log_description .= "<br>Sr. Secondary University " . $old_qual->sr_secondary_university . " to " . $this->input->post('sr_secondary_university');
			}

			if ($old_qual->sr_secondary_marks != $this->input->post('sr_secondary_marks')) {

				$add_log = 0;

				$log_description .= "<br>Sr. Secondary Marks " . $old_qual->sr_secondary_marks . " to " . $this->input->post('sr_secondary_marks');
			}

			if ($old_qual->graduation_year != $this->input->post('graduation_year')) {

				$add_log = 0;

				$log_description .= "<br>Graduation Year " . $old_qual->graduation_year . " to " . $this->input->post('graduation_year');
			}

			if ($old_qual->graduation_university != $this->input->post('graduation_university')) {

				$add_log = 0;

				$log_description .= "<br>Graduation University " . $old_qual->graduation_university . " to " . $this->input->post('graduation_university');
			}

			if ($old_qual->graduation_marks != $this->input->post('graduation_marks')) {

				$add_log = 0;

				$log_description .= "<br>Graduation Marks " . $old_qual->graduation_marks . " to " . $this->input->post('graduation_marks');
			}

			if ($old_qual->post_graduation_year != $this->input->post('post_graduation_year')) {

				$add_log = 0;

				$log_description .= "<br>Post Graduation Year " . $old_qual->post_graduation_year . " to " . $this->input->post('post_graduation_year');
			}

			if ($old_qual->post_graduation_university != $this->input->post('post_graduation_university')) {

				$add_log = 0;

				$log_description .= "<br>Post Graduation University " . $old_qual->post_graduation_university . " to " . $this->input->post('post_graduation_university');
			}

			if ($old_qual->post_graduation_marks != $this->input->post('post_graduation_marks')) {

				$add_log = 0;

				$log_description .= "<br>Post Graduation Marks " . $old_qual->post_graduation_marks . " to " . $this->input->post('post_graduation_marks');
			}

			if ($old_qual->other_qualification_year != $this->input->post('other_qualification_year')) {

				$add_log = 0;

				$log_description .= "<br>Other Year " . $old_qual->other_qualification_year . " to " . $this->input->post('other_qualification_year');
			}

			if ($old_qual->other_qualification_university != $this->input->post('other_qualification_university')) {

				$add_log = 0;

				$log_description .= "<br>Other University " . $old_qual->other_qualification_university . " to " . $this->input->post('other_qualification_university');
			}

			if ($old_qual->other_qualification_marks != $this->input->post('other_qualification_marks')) {

				$add_log = 0;

				$log_description .= "<br>Other Marks " . $old_qual->other_qualification_marks . " to " . $this->input->post('other_qualification_marks');
			}
		} else {

			$add_log = 0;

			$log_description = $profile->first_name . " " . $profile->last_name . " has added qualification details of " . $student_row->student_name . " (" . $student_row->id . ")" . " on " . date("d/m/Y");

			$log_description .= "<br>Secondary year " . $this->input->post('secondary_year');

			$log_description .= "<br>Secondary University " . $this->input->post('secondary_university');

			$log_description .= "<br>Secondary Marks " . $this->input->post('secondary_marks');

			$log_description .= "<br>Sr Secondary year " . $this->input->post('sr_secondary_year');

			$log_description .= "<br>Sr. Secondary University " . $this->input->post('sr_secondary_university');

			$log_description .= "<br>Sr. Secondary Marks " . $this->input->post('sr_secondary_marks');

			$log_description .= "<br>Graduation year " . $this->input->post('graduation_year');

			$log_description .= "<br>Graduation University " . $this->input->post('graduation_university');

			$log_description .= "<br>Graduation Marks " . $this->input->post('graduation_marks');

			$log_description .= "<br>Post Graduation year " . $this->input->post('post_graduation_year');

			$log_description .= "<br>Post Graduation University " . $this->input->post('post_graduation_university');

			$log_description .= "<br>Post Graduation Marks " . $this->input->post('post_graduation_marks');

			$log_description .= "<br>Other Year " . $this->input->post('other_qualification_year');

			$log_description .= "<br>Other University " . $this->input->post('other_qualification_university');

			$log_description .= "<br>Other Marks " . $this->input->post('other_qualification_marks');
		}

		if ($add_log == 0) {

			$log = array(

				'user_id' 		=> $this->session->userdata('admin_id'),

				'student_id' 	=> $student_row->id,

				'description' 	=> $log_description,

				'date' 			=> date("Y-m-d"),

				'created_on' 	=> date("Y-m-d H:i:s"),

			);

			$this->Setting_model->set_log($log);
		}



		$this->db->select('id,faculty,course_type,course_mode');

		$this->db->where('course', $this->input->post('course'));

		$this->db->where('stream', $this->input->post('stream'));

		$this->db->where('is_deleted', '0');

		$this->db->where('status', '1');

		$course = $this->db->get('tbl_course_stream_relation');

		$course = $course->row();

		$admission_type = $this->input->post('admission_type');

		if ($this->input->post('year_sem') != "1") {

			$entry_year = $this->input->post('year_sem');
		} else {



			$entry_year = "0";
		}



		if ($photo == "") {

			$photo = $this->input->post('old_photo');
		}

		if ($permission_letter == "") {

			$permission_letter = $this->input->post('old_permission_letter');
		}

		if ($identity_softcopy == "") {

			$identity_softcopy = $this->input->post('old_identity_softcopy');
		}

		if ($ohter_files == "") {

			$ohter_files = $this->input->post('old_ohter_files');
		}

		if ($signature == "") {

			$signature = $this->input->post('old_signature');
		}

		if ($secondary_marksheet == "") {

			$secondary_marksheet = $this->input->post('old_secondary_marksheet');
		}

		if ($sr_secondary_marksheet == "") {

			$sr_secondary_marksheet = $this->input->post('old_sr_secondary_marksheet');
		}

		if ($graduation_marksheet == "") {

			$graduation_marksheet = $this->input->post('old_graduation_marksheet');
		}

		if ($post_graduation_marksheet == "") {

			$post_graduation_marksheet = $this->input->post('old_post_graduation_marksheet');
		}

		if ($other_qualification_marksheet == "") {

			$other_qualification_marksheet = $this->input->post('old_other_qualification_marksheet');
		}

		if ($undertaking == "") {

			$undertaking = $this->input->post('old_undertaking');
		}



		$qualification = array(

			'student_id' 					=> $this->input->post('student_id'),

			'secondary_year' 				=> $this->input->post('secondary_year'),

			'secondary_university' 			=> $this->input->post('secondary_university'),

			'secondary_marks' 				=> $this->input->post('secondary_marks'),

			'sr_secondary_year' 			=> $this->input->post('sr_secondary_year'),

			'sr_secondary_university' 		=> $this->input->post('sr_secondary_university'),

			'sr_secondary_marks' 			=> $this->input->post('sr_secondary_marks'),

			'graduation_year' 				=> $this->input->post('graduation_year'),

			'graduation_university' 		=> $this->input->post('graduation_university'),

			'graduation_marks' 				=> $this->input->post('graduation_marks'),

			'post_graduation_year' 			=> $this->input->post('post_graduation_year'),

			'post_graduation_university' 	=> $this->input->post('post_graduation_university'),

			'post_graduation_marks' 		=> $this->input->post('post_graduation_marks'),

			'other_qualification_year' 		=> $this->input->post('other_qualification_year'),

			'other_qualification_university' => $this->input->post('other_qualification_university'),

			'other_qualification_marks' 	=> $this->input->post('other_qualification_marks'),

			'secondary_marksheet' 			=> $secondary_marksheet,

			'sr_secondary_marksheet' 		=> $sr_secondary_marksheet,

			'graduation_marksheet' 			=> $graduation_marksheet,

			'post_graduation_marksheet' 	=> $post_graduation_marksheet,

			'other_qualification_marksheet' => $other_qualification_marksheet,

		);

		$this->db->where('student_id', $this->input->post('student_id'));

		$qu_exist = $this->db->get('tbl_student_qualification');

		$qu_exist = $qu_exist->row();

		if (empty($qu_exist)) {

			$date = array(

				'created_on' => date("Y-m-d H:i:s")

			);

			$new_qualification = array_merge($qualification, $date);

			$this->db->insert('tbl_student_qualification', $new_qualification);
		} else {

			$this->db->where('student_id', $this->input->post('student_id'));

			$this->db->update('tbl_student_qualification', $qualification);
		}

		$data = array(

			'faculty_id' 		=> $course->faculty,

			'course_type' 		=> $course->course_type,

			'course_mode' 		=> $this->input->post("course_mode"),

			'session_id' 		=> $this->input->post('session'),

			'course_id' 		=> $this->input->post('course'),

			'course_update_reason' => $this->input->post('course_update_reason'),

			'center_id' 		=> $this->input->post('center'),

			'stream_id' 		=> $this->input->post('stream'),

			'year_sem' 			=> $this->input->post('year_sem'),

			'father_name' 		=> $this->input->post('father_name'),

			'mother_name' 		=> $this->input->post('mother_name'),

			'date_of_birth' 	=> date("Y-m-d", strtotime($this->input->post('date_of_birth'))),

			'mobile' 			=> $this->input->post('mobile'),

			'email' 			=> $this->input->post('email'),

			'gender' 			=> $this->input->post('gender'),

			'admission_type' 	=> $admission_type,

			'study_mode' 	    => $this->input->post("study_mode"),

			'lateral_year' 		=> $entry_year,

			'address' 			=> $this->input->post('address'),

			'country' 			=> $this->input->post('country'),

			'state' 			=> $this->input->post('state'),

			'city' 				=> $this->input->post('city'),

			'pincode' 			=> $this->input->post('pincode'),

			'admission_status'	=> $this->input->post('admission_status'),

			'employement_type'	=> $this->input->post('employement_type'),

			'religion'			=> $this->input->post('religion'),

			'religin_specify'	=> $this->input->post('religin_specify'),

			'show_collaborator_undertaking'	=> $this->input->post('show_collaborator_undertaking'),

			'show_center_collaborator_undertaking'	=> $this->input->post('show_center_collaborator_undertaking'),

			'show_center_undertaking'	=> $this->input->post('show_center_undertaking'),

			'show_undertaking'	=> $this->input->post('show_undertaking'),

			'admission_date'	=> date("Y-m-d", strtotime($this->input->post('admission_date'))),

			'photo' 			=> $photo,

			'noc'               => $noc,

			'permission_letter' => $permission_letter,

			'signature' 		=> $signature,

			'identity_softcopy' => $identity_softcopy,

			'ohter_files' 		=> $ohter_files,

			'undertaking' 		=> $undertaking,

		);

		$this->db->where('id', $this->input->post('student_id'));

		$this->db->update('tbl_student', $data);



		$this->db->where('id', $this->input->post('student_id'));

		$old_data = $this->db->get('tbl_student');

		$old_data = $old_data->row();



		$this->db->where('session_id', $old_data->session_id);

		$this->db->where('relation_id', $course->id);

		$this->db->where('course_id', $old_data->course_id);

		$this->db->where('stream_id', $old_data->stream_id);

		$result = $this->db->get('tbl_fees_realtion');

		$result = $result->row();



		$late_fees = 0;

		$this->db->where('id', $old_data->session_id);

		$this->db->where('late_fees_date<', date("Y-m-d"));

		$seesion_late = $this->db->get('tbl_session');

		$seesion_late = $seesion_late->row();

		if (!empty($seesion_late)) {

			$late_fees = $seesion_late->late_fees;
		}



		$fees = 0;

		if (!empty($result)) {

			$fees = $result->fees;
		} else {

			$this->db->where('relation_id', $course->id);

			$this->db->where('course_id', $old_data->course_id);

			$this->db->where('stream_id', $old_data->stream_id);

			$this->db->order_by('id', 'DESC');

			$result = $this->db->get('tbl_fees_realtion');

			$result = $result->row();

			if (!empty($result)) {

				$fees = $result->fees;
			}
		}

		if ($old_data->country != "101") {

			$fees = $fees * 2;
		}

		$bank_id = 1;

		$fees_data = array(

			'student_id' 	=> $this->input->post('student_id'),

			'fees_type' 	=> 1,

			'year_sem' 		=> $this->input->post('year_sem'),

			'payment_mode' 	=> '3',

			'payment_date' 	=> date("Y-m-d"),

			'bank_id' 		=> $bank_id,

			'late_fees' 	=> $late_fees,

			'bank_fees' 	=> 0,

			'amount' 		=> $fees,

			'original_amount' => $fees,

			'total_fees' 	=> $fees + $late_fees,

			'created_on' 	=> date("Y-m-d H:i:s"),

		);

		$this->db->insert('tbl_student_fees', $fees_data);

		return true;
	}

	public function get_phd_stream($course)
	{

		$this->db->select('tbl_stream.stream_name,tbl_stream.id');

		$this->db->where('tbl_course_stream_relation.course', $course);

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_course_stream_relation.stream');

		$result = $this->db->get('tbl_course_stream_relation');

		return $result->result();
	}

	public function get_all_student_fees()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		// $this->db->where('payment_status', '1'); 
		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student_fees');
		return $result->result();
	}

	public function get_single_student_fees()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('id', $this->uri->segment(3));
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student_fees');
		return $result->row();
	}


	public function get_single_lateral_student_fees()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student_fees');
		return $result->row();
	}

	public function get_single_registration_fees($center_id, $course_id, $stream_id)
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		$this->db->where('center_id', $center_id);
		$this->db->where('course_id', $course_id);
		$this->db->where('stream_id', $stream_id);
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_center_fees');
		return $result->row();
	}

	public function update_student_account()
	{
		$data = array(

			'student_id' 		=> $this->input->post('student_id'),

			'fees_type' 		=> $this->input->post('fees_type'),

			'payment_mode' 		=> $this->input->post('payment_mode'),

			'payment_date' 		=> date("Y-m-d", strtotime($this->input->post('payment_date'))),

			'payment_status' 	=> $this->input->post('payment_status'),

			'transaction_id' 	=> $this->input->post('transaction_id'),

			'bank_id' 			=> $this->input->post('bank'),

			'late_fees' 		=> $this->input->post('late_fees'),

			'bank_fees' 		=> $this->input->post('bank_fees'),

			'original_amount' 	=> $this->input->post('amount'),

			'amount' 			=> $this->input->post('amount'),

			'discount' 			=> $this->input->post('discount'),

			'total_fees' 		=> $this->input->post('total_fees'),

			'registration_fees' => $this->input->post('registration_fees'),

			'year_sem' 			=> $this->input->post('year_sem'),

			'remark' 			=> $this->input->post('remark'),

		);
		if ($this->input->post('id') == "0") {

			$date = array(

				'created_on' => date("Y-m-d H:i:s"),

			);

			$new_arr = array_merge($data, $date);

			$this->db->insert('tbl_student_fees', $new_arr);

			$last_fees = $this->db->insert_id();
		} else {

			$this->db->where('id', $this->input->post('id'));

			$this->db->update('tbl_student_fees', $data);

			$last_fees = $this->input->post('id');
		}

		$this->db->where('id', $this->input->post('student_id'));

		$student_row = $this->db->get('tbl_student');

		$student_row = $student_row->row();

		$profile = $this->Admin_model->get_profile();

		if ($this->input->post('payment_status') == "1") {

			$pay_status = "Success";
		} else {

			$pay_status = "Failed";
		}

		if ($this->input->post('id') == "0") {

			$log_description = $profile->first_name . " " . $profile->last_name . " has added fees Rs. " . $this->input->post('total_fees') . " (" . $last_fees . ") and transaction no is " . $this->input->post('transaction_id') . " and status " . $pay_status . " of " . $student_row->student_name . " (" . $student_row->id . ")" . " on " . date("d/m/Y");

			$return = 0;
		} else {

			$log_description = $profile->first_name . " " . $profile->last_name . " has updated fees Rs. " . $this->input->post('total_fees') . " (" . $last_fees . ") and transaction no is " . $this->input->post('transaction_id') . " and status " . $pay_status . " of " . $student_row->student_name . " (" . $student_row->id . ")" . " on " . date("d/m/Y");

			$return = 1;
		}

		$log = array(

			'user_id' 		=> $this->session->userdata('admin_id'),

			'student_id' 	=> $student_row->id,

			'description' 	=> $log_description,

			'date' 			=> date("Y-m-d"),

			'created_on' 	=> date("Y-m-d H:i:s"),

		);

		$this->Setting_model->set_log($log);

		return $return;
	}

	public function get_single_qualification()
	{

		$this->db->where('student_id', $this->uri->segment(2));

		$result = $this->db->get('tbl_student_qualification');

		return $result->row();
	}

	public function get_selected_state($country)
	{

		$this->db->where('country_id', $country);

		$result = $this->db->get('states');

		return $result->result();
	}

	public function get_selected_city($state)
	{

		$this->db->where('state_id', $state);

		$result = $this->db->get('cities');

		return $result->result();
	}

	public function get_all_student_feedback_list($length, $start, $search)
	{
		$this->db->select('tbl_student.student_name,tbl_course.print_name,tbl_student_feedback.*,tbl_employees.first_name,tbl_employees.last_name');
		$this->db->where('tbl_student_feedback.is_deleted', '0');
		$this->db->where('tbl_student_feedback.status', '1');
		$this->db->where('tbl_student_feedback.replied_by', '0');
		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student_feedback.feedback', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_course.print_name', $search);

			$this->db->group_end();
		}
		$this->db->order_by('tbl_student_feedback.id', 'DESC');
		$this->db->limit($length, $start);

		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_feedback.student_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student_feedback.replied_by', 'left');
		$result = $this->db->get('tbl_student_feedback');

		return $result->result();
	}

	public function get_all_student_feedback_list_count($search)
	{
		$this->db->select('tbl_student.student_name,tbl_course.print_name,tbl_student_feedback.*,tbl_employees.first_name,tbl_employees.last_name');
		$this->db->where('tbl_student_feedback.is_deleted', '0');
		$this->db->where('tbl_student_feedback.status', '1');
		$this->db->where('tbl_student_feedback.replied_by', '0');
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student_feedback.feedback', $search);
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_course.print_name', $search);
			$this->db->or_like('tbl_employees.first_name', $search);
			$this->db->or_like('tbl_employees.last_name', $search);
			$this->db->group_end();
		}
		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_feedback.student_id');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student_feedback.replied_by', 'left');
		$result = $this->db->get('tbl_student_feedback');
		return $result->num_rows();
	}
	public function get_all_replied_student_feedback_list($length, $start, $search)
	{
		$this->db->select('tbl_student.student_name,tbl_course.print_name,tbl_student_feedback.*,tbl_employees.first_name,tbl_employees.last_name');
		$this->db->where('tbl_student_feedback.is_deleted', '0');

		$this->db->where('tbl_student_feedback.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student_feedback.feedback', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_course.print_name', $search);

			$this->db->group_end();
		}
		$this->db->order_by('tbl_student_feedback.id', 'DESC');
		$this->db->limit($length, $start);
		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_feedback.student_id');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student_feedback.replied_by', 'left');
		$result = $this->db->get('tbl_student_feedback');
		return $result->result();
	}
	public function get_all_replied_student_feedback_list_count($search)
	{
		$this->db->select('tbl_student.student_name,tbl_course.print_name,tbl_student_feedback.*,tbl_employees.first_name,tbl_employees.last_name');
		$this->db->where('tbl_student_feedback.is_deleted', '0');
		$this->db->where('tbl_student_feedback.status', '1');
		$this->db->where('tbl_student_feedback.replied_by !=', '0');
		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student_feedback.feedback', $search);
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_course.print_name', $search);
			$this->db->or_like('tbl_employees.first_name', $search);
			$this->db->or_like('tbl_employees.last_name', $search);
			$this->db->group_end();
		}
		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_feedback.student_id');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_employees', 'tbl_employees.id = tbl_student_feedback.replied_by', 'left');

		$result = $this->db->get('tbl_student_feedback');

		return $result->num_rows();
	}

	public function get_all_session()
	{

		$this->db->where('is_deleted', '0');

		$result = $this->db->get('tbl_session');

		return $result->result();
	}







	public function get_amount_filter()
	{

		$this->db->select("tbl_student_fees.*,tbl_student.*,tbl_center.center_name,tbl_session.session_name");



		$this->db->where("tbl_student_fees.is_deleted", "0");

		$this->db->where("tbl_student_fees.status", "1");

		$this->db->where("tbl_student_fees.payment_status", "1");



		if (!empty($_GET["student"])) {

			$this->db->where("tbl_student_fees.student_id", $_GET["student"]);
		}

		if (!empty($_GET["transaction_id"])) {

			$this->db->where("tbl_student_fees.transaction_id", $_GET["transaction_id"]);
		}

		if (!empty($_GET["year"])) {

			$this->db->where("year(tbl_student_fees.created_on)", $_GET["year"]);
		}

		if (!empty($_GET["month"])) {

			$this->db->where("month(tbl_student_fees.created_on)", $_GET["month"]);
		}

		if (!empty($_GET["center"])) {

			$this->db->where("tbl_student.center_id", $_GET["center"]);
		}

		if (!empty($_GET["session"])) {

			$this->db->where("tbl_student.session_id", $_GET["session"]);
		}



		$this->db->join("tbl_student", "tbl_student.id=tbl_student_fees.student_id");

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");

		$this->db->join("tbl_session", "tbl_session.id=tbl_student.session_id");

		$this->db->order_by("tbl_student_fees.id", "DESC");

		$result = $this->db->get("tbl_student_fees")->result();

		return $result;
	}





	public function get_all_reregistered_student_ajax($length, $start, $search)
	{

		$this->db->select("tbl_re_registered_student.*,tbl_student.center_id,tbl_student.student_name,tbl_center.center_name");

		$this->db->where('tbl_re_registered_student.is_deleted', '0');

		$this->db->where('tbl_re_registered_student.payment_status', '1');

		$this->db->where('tbl_re_registered_student.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_re_registered_student.enrollment_number', $search);

			$this->db->or_like('tbl_re_registered_student.previous_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.current_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.transaction_id', $search);

			$this->db->or_like('tbl_re_registered_student.created_on', $search);



			$this->db->or_like('tbl_student.student_name', $search);



			$this->db->group_end();
		}

		$this->db->order_by('tbl_re_registered_student.id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join("tbl_student", "tbl_student.id=tbl_re_registered_student.student_id");

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");

		$result = $this->db->get('tbl_re_registered_student');

		return $result->result();
	}

	public function get_all_reregistered_student_ajax_count($search)
	{

		$this->db->select("tbl_re_registered_student.*,tbl_student.center_id,tbl_student.student_name,tbl_center.center_name");

		$this->db->where('tbl_re_registered_student.is_deleted', '0');

		$this->db->where('tbl_re_registered_student.payment_status', '1');

		$this->db->where('tbl_re_registered_student.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_re_registered_student.enrollment_number', $search);

			$this->db->or_like('tbl_re_registered_student.previous_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.current_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.transaction_id', $search);

			$this->db->or_like('tbl_re_registered_student.created_on', $search);



			$this->db->or_like('tbl_student.student_name', $search);



			$this->db->group_end();
		}

		$this->db->join("tbl_student", "tbl_student.id=tbl_re_registered_student.student_id");

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");

		$result = $this->db->get('tbl_re_registered_student');

		return $result->num_rows();
	}



	public function get_all_reregistered_student_failed_ajax($length, $start, $search)
	{

		$this->db->select("tbl_re_registered_student.*,tbl_student.center_id,tbl_student.student_name,tbl_center.center_name");
		$this->db->where('tbl_re_registered_student.is_deleted', '0');
		$this->db->where('tbl_re_registered_student.payment_status', '0');
		$this->db->where('tbl_re_registered_student.status', '1');
		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_re_registered_student.enrollment_number', $search);

			$this->db->or_like('tbl_re_registered_student.previous_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.current_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.created_on', $search);
			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_re_registered_student.id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join("tbl_student", "tbl_student.id=tbl_re_registered_student.student_id");

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");

		$result = $this->db->get('tbl_re_registered_student');

		return $result->result();
	}

	public function get_all_reregistered_student_failed_ajax_count($search)
	{

		$this->db->select("tbl_re_registered_student.*,tbl_student.center_id,tbl_student.student_name,tbl_center.center_name");

		$this->db->where('tbl_re_registered_student.is_deleted', '0');

		$this->db->where('tbl_re_registered_student.payment_status', '0');
		$this->db->where('tbl_re_registered_student.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_re_registered_student.enrollment_number', $search);

			$this->db->or_like('tbl_re_registered_student.previous_year_sem', $search);

			$this->db->or_like('tbl_re_registered_student.current_year_sem', $search);



			$this->db->or_like('tbl_re_registered_student.created_on', $search);



			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->group_end();
		}

		$this->db->join("tbl_student", "tbl_student.id=tbl_re_registered_student.student_id");

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");



		$result = $this->db->get('tbl_re_registered_student');

		return $result->num_rows();
	}





	public function student_re_registration_edit()
	{
		$payment_data = array(
			"student_id"	=> $this->input->post("student_id"),
			"fees_type"		=> '4',
			"bank_id"		=> $this->input->post("bank"),
			"payment_mode"	=> $this->input->post("payment_mode"),
			"payment_date"	=> date("Y-m-d", strtotime($this->input->post("payment_date"))),
			"original_amount" => $this->input->post("original_fees"),
			"amount"		=> $this->input->post("university_share"),
			"total_fees"	=> $this->input->post("original_fees"),
			"year_sem"		=> $this->input->post("year_sem"),
			"created_on"	=> date("Y-m-d H:i:s"),
			'transaction_id' => $this->input->post("transaction_id"),
			'payment_status' => $this->input->post("payment_status"),
			'remark' 		=> $this->input->post("remark"),
		);
		$this->db->insert("tbl_student_fees", $payment_data);
		$fees_id = $this->db->insert_id();
		// echo "<pre>";print_r($this->input->post("year_sem"));exit;
		$maintain_data = array(
			"previous_year_sem" => $this->input->post("previous_year_sem"),
			"current_year_sem" 	=> $this->input->post("year_sem"),
			'transaction_id' 	=> $this->input->post("transaction_id"),
			'payment_status' 	=> $this->input->post("payment_status"),
		);
		$this->db->where("tbl_re_registered_student.id", $this->uri->segment(2));
		$this->db->update("tbl_re_registered_student", $maintain_data);
		if ($this->input->post("payment_status") == "1") {
			$stu_data = array(
				"year_sem" => $this->input->post("year_sem"),
			);
			$this->db->where("tbl_student.id", $this->input->post("student_id"));
			$this->db->update("tbl_student", $stu_data);
		}
	}



	public function get_failed_re_registered_student($id)
	{

		//echo $id;exit;

		$this->db->select("tbl_student.*,tbl_center.fee_share,tbl_fees_realtion.fees");



		$this->db->where("tbl_student.is_deleted", "0");

		$this->db->where("tbl_student.status", "1");

		$this->db->where("tbl_student.id", $id);

		$this->db->join("tbl_center", "tbl_center.id=tbl_student.center_id");

		/*	$this->db->join('tbl_fees_realtion','tbl_fees_realtion.course_id = tbl_student.course_id AND tbl_fees_realtion.stream_id = tbl_student.stream_id AND tbl_fees_realtion.session_id = tbl_student.session_id');*/

		$this->db->join('tbl_fees_realtion', 'tbl_fees_realtion.course_id = tbl_student.course_id AND tbl_fees_realtion.stream_id = tbl_student.stream_id');

		$result = $this->db->get("tbl_student")->row();

		//echo "<pre>";

		//print_r($result);exit;



		$result_array = array();



		if (!empty($result->fee_share)) {

			$result_array["university_share"]  = $result->fees - (($result->fee_share / 100) * $result->fees);
		} else {

			$result_array["university_share"]  = $result->fees;
		}



		$result_array["original_fees"] = $result->fees;

		$result_array["id"] = $result->id;

		$result_array["enrollment_number"] = $result->enrollment_number;

		$result_array["year_sem"] = $result->year_sem;



		return $result_array;
	}


	public function get_all_panding_re_registration_student_list_ajax($length, $start, $search)
	{

		$this->db->select("tbl_student.*,tbl_exam_results.result,tbl_center.center_name");
		$this->db->where('tbl_student.is_deleted', '0');

		// $this->db->where('tbl_student.verified_status','1');

		$this->db->where('tbl_student.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.created_on', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->limit($length, $start);

		$this->db->join("tbl_exam_results", "tbl_exam_results.student_id=tbl_student.id AND tbl_exam_results.year_sem = tbl_student.year_sem AND tbl_exam_results.is_deleted = '0'");

		$this->db->join("tbl_center", "tbl_center.id = tbl_student.center_id");

		$result = $this->db->get('tbl_student');

		return $result->result();
		// $result = $result->result();		
		// echo "<pre>";print_r($result);exit;

	}

	public function get_all_panding_re_registration_student_list_ajax_count($search)
	{

		$this->db->select("tbl_student.*,tbl_exam_results.result");

		$this->db->where('tbl_student.is_deleted', '0');

		// $this->db->where('tbl_student.verified_status','1');

		$this->db->where('tbl_student.status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.created_on', $search);

			$this->db->group_end();
		}

		$this->db->join("tbl_exam_results", "tbl_exam_results.student_id=tbl_student.id AND tbl_exam_results.year_sem = tbl_student.year_sem AND tbl_exam_results.is_deleted = '0'");

		$this->db->join("tbl_center", "tbl_center.id = tbl_student.center_id");

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function get_student_paid_addmission_fees()
	{
		$this->db->where('status', '1');
		$this->db->where('payment_status', '1');
		$this->db->where('fees_type', '1');
		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student_fees');
		return $result->result();
	}

	public function get_student_paid_exam_fees()
	{

		$this->db->where('status', '1');

		$this->db->where('payment_status', '1');

		$this->db->where('fees_type', '2');

		$this->db->where('student_id', $this->uri->segment(2));

		$this->db->order_by('id', 'DESC');

		$result = $this->db->get('tbl_student_fees');

		return $result->result();
	}

	public function get_student_paid_addmission_fees_ajax($student_id)
	{

		$this->db->where('status', '1');

		$this->db->where('payment_status', '1');

		$this->db->where('fees_type', '1');

		$this->db->where('student_id', $student_id);

		$this->db->order_by('id', 'DESC');

		$result = $this->db->get('tbl_student_fees');

		return $result->result();
	}

	public function get_student_paid_exam_fees_ajax($student_id)
	{

		$this->db->where('status', '1');

		$this->db->where('payment_status', '1');

		$this->db->where('fees_type', '2');

		$this->db->where('student_id', $student_id);

		$this->db->order_by('id', 'DESC');

		$result = $this->db->get('tbl_student_fees');

		return $result->result();
	}

	public function get_student_total_payable_fees($student_id)
	{
		$student_fees = 0;
		$course_fees = 0;
		$final_student_fees = 0;

		$this->db->where('id', $student_id);
		$student = $this->db->get('tbl_student');
		$student = $student->row();

		if (!empty($student)) {
			$this->db->where('id', $student->center_id);
			$center = $this->db->get('tbl_center');
			$center = $center->row();

			$this->db->where('course_id', $student->course_id);
			$this->db->where('stream_id', $student->stream_id);
			$this->db->where('session_id', $student->session_id);
			$this->db->where('center_id', $student->center_id);
			$this->db->where('is_deleted', '0');
			$fees_result = $this->db->get('tbl_center_fees');
			$fees_result = $fees_result->row();

			if (empty($fees_result)) {
				$this->db->where('course_id', $student->course_id);
				$this->db->where('stream_id', $student->stream_id);
				$this->db->where('center_id', $student->center_id);
				$this->db->where('is_deleted', '0');
				$this->db->order_by('session_id', 'DESC');
				$fees_result = $this->db->get('tbl_center_fees');
				$fees_result = $fees_result->row();
			}
			$course_fees = 0;
			if (!empty($fees_result)) {
				if ($student->country != "101") {
					$course_fees = $fees_result->foregin_fees;
				} else {
					$course_fees = $fees_result->fees;
				}
				$registration_fees = $fees_result->registration_fees;
			}

			if (!is_numeric($course_fees)) {
				$course_fees = 0;
			} else {
				$course_fees = (float)$course_fees;
			}

			$course_yearly_fees = $course_fees;
			$course_halfyearly_fees = $course_fees / 2;

			if ($student->admission_type == '0') {
				if ($student->course_mode == '1') {
					$student_fees = $course_yearly_fees * intval($student->year_sem);
				} else if ($student->course_mode == '2') {
					$student_fees = $course_yearly_fees * $student->year_sem;
				}
			} else {
				if ($student->course_mode == '1') {
					$lateral_diffrent = $student->year_sem - $student->lateral_year;
					$lateral_diffrent = $lateral_diffrent + 1;
					$student_fees = $course_yearly_fees * $lateral_diffrent;
				} else if ($student->course_mode == '2') {
					$lateral_diffrent = $student->year_sem - $student->lateral_year;
					$lateral_diffrent = $lateral_diffrent + 1;
					$student_fees = $course_yearly_fees * $lateral_diffrent;
				}
			}
			if ($student->payment_term == "2") {
				$student_fees = $student_fees / 2;
			}
			$final_fees = $student_fees + $registration_fees;
		}
		// return $course_fees;
		return $final_fees;
	}

	public function get_student_lateral_fees()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		$result = $this->db->get('tbl_lateral_entry_fees');
		$result = $result->row();
		if (!empty($result)) {
			return $result->fees_amount;
		} else {
			return 0;
		}
	}

	public function get_center_fees_sharing($center_id)
	{

		$this->db->where('id', $center_id);

		$result = $this->db->get('tbl_center');

		$result = $result->row();

		if (!empty($result)) {

			if ($result->fee_share != "") {

				return $result->fee_share;
			} else {

				return 0;
			}
		} else {

			return 0;
		}
	}

	public function set_cancel_student_remark()
	{

		$data = array(

			'admission_status' 	=> '2',

			'cancel_remark' 	=> $this->input->post('remark'),

		);

		$this->db->where('id', $this->input->post('student_id'));

		$this->db->update('tbl_student', $data);

		return true;
	}



	public function get_all_cancel_admission_list($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');  
		$this->db->where('tbl_student.admission_status', '2');
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.enrollment_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_all_cancel_admission_list_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');


		$this->db->where('tbl_student.admission_status', '2');
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function get_all_hold_admission_list($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');
		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		$this->db->where('tbl_student.verified_status', '1');

		// $this->db->where('tbl_student.admission_status','3');   


		$this->db->where('tbl_student.hold_login', '1');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.enrollment_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_all_hold_admission_list_count($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		if ($this->input->post('type') != '') {
			$this->db->where('tbl_student.course_for', $this->input->post('type'));
		}

		$this->db->where('tbl_student.verified_status', '1');

		// $this->db->where('tbl_student.admission_status','3'); 


		$this->db->where('tbl_student.hold_login', '1');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}



	public function get_student_enrolled_fees_cal($student_id)
	{

		$student_fees = 0;

		$course_fees = 0;

		$final_student_fees = 0;



		$this->db->where('id', $student_id);

		$result = $this->db->get('tbl_student');

		$result = $result->row();

		if (!empty($result)) {

			$this->db->where('is_deleted', '0');

			$this->db->where('status', '1');

			$this->db->where('course', $result->course_id);

			$this->db->where('stream', $result->stream_id);

			$relation = $this->db->get('tbl_course_stream_relation');

			$relation = $relation->row();

			if (!empty($relation)) {

				$this->db->where('session_id', $result->session_id);

				$this->db->where('relation_id', $relation->id);

				$this->db->where('course_id', $result->course_id);

				$this->db->where('stream_id', $result->stream_id);

				$course_fee = $this->db->get('tbl_fees_realtion');

				$course_fee = $course_fee->row();

				if (!empty($course_fee)) {

					if ($result->center_id == "1") {

						$course_fees =  $course_fee->campus_fees;
					} else {

						$course_fees =  $course_fee->fees;
					}
				} else {

					$this->db->where('relation_id', $relation->id);

					$this->db->where('course_id', $result->course_id);

					$this->db->where('stream_id', $result->stream_id);

					$this->db->order_by('id', 'DESC');

					$course_fee = $this->db->get('tbl_fees_realtion');

					$course_fee = $course_fee->row();

					if (!empty($course_fee)) {

						if ($result->center_id == "1") {

							$course_fees =  $course_fee->campus_fees;
						} else {

							$course_fees =  $course_fee->fees;
						}
					}
				}
			}

			if ($result->country != "101") {

				$course_fees = $course_fees * 2;
			}

			//echo $course_fees;exit;

			$course_yearly_fees = $course_fees;

			$course_halfyearly_fees = $course_fees / 2;

			$lateral_fees = 0;

			if ($result->admission_type == '0') {

				if ($result->course_mode == '1') {

					$student_fees = $course_yearly_fees * $result->year_sem;
				} else if ($result->course_mode == '2') {



					$student_fees = $course_yearly_fees * $result->year_sem;
				}
			} else {

				$this->db->where('is_deleted', '0');

				$this->db->where('status', '1');

				$this->db->order_by('id', 'DESC');

				$lateral_fee_result = $this->db->get('tbl_lateral_entry_fees');

				$lateral_fee_result = $lateral_fee_result->row();

				if ($result->course_mode == '1') {

					if (!empty($lateral_fee_result)) {

						$lateral_fees = $lateral_fee_result->fees_amount;
					}
				} else if ($result->course_mode == '2') {

					if (!empty($lateral_fee_result)) {

						$lateral_fees = $lateral_fee_result->fees_amount;
					}
				}
			}

			if ($result->center_id == '1') {

				$final_student_fees = $student_fees;
			} else if ($result->center_id != '1') {

				$center_share = $this->get_center_fees_sharing($result->center_id);



				if ($center_share != "0") {

					$final_student_fees = ($center_share / 100) * $student_fees;
				} else {

					$final_student_fees = $student_fees;
				}

				//$final_student_fees = $student_fees;

			}

			//echo $final_student_fees;exit;

		}

		return $final_student_fees + $lateral_fees;
	}

	public function get_new_thesis_list($length, $start, $search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_thesis.id', 'DESC');

		$this->db->limit($length, $start);

		//$this->db->where('thesis_status','1');

		//$this->db->where('thesis_status','2');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->result();
	}

	public function get_new_thesis_list_count($search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');



		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_thesis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->num_rows();
	}

	public function get_single_thesis()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('status', '1');

		$result = $this->db->get('tbl_thesis');

		return $result->row();
	}

	public function get_active_guide_list()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('status', '1');

		$this->db->where('appliation_status', '1');

		$result = $this->db->get('tbl_guide_application');

		return $result->result();
	}

	public function get_update_thesis($file1)
	{

		if ($file1 == "") {

			$file1 = $this->input->post("softcopy");
		}

		$data = array(

			'thesis_title'	  => $this->input->post('thesis_title'),

			'paper_journal1'  => $this->input->post('paper_journal1'),

			'softcopy'        => $file1,

			'guide_id'        => $this->input->post('guide_name'),

			'thesis_status'   => $this->input->post('thesis_status'),

			'remarks'        => $this->input->post('remarks'),

			'submission_date' => date("Y-m-d", strtotime($this->input->post('submission_date'))),
		);

		// echo "<pre>";print_r($data);exit;
		$this->db->where('id', $this->uri->segment(2));

		$this->db->update('tbl_thesis', $data);

		return 1;
	}

	public function set_reject_thesis()
	{

		$data = array(

			'remarks' => $this->input->post('rejection_remark_teacher'),

			'thesis_status' => '1',

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_thesis', $data);

		$this->db->select('tbl_student.email');

		$this->db->where('tbl_thesis.id', $this->input->post('id'));

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$result = $this->db->get('tbl_thesis');

		$result = $result->row();



		$message = '

			<!DOCTYPE html>

                <html>

                    <head>

                        <title></title>

                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

                        <meta name="viewport" content="width=device-width, initial-scale=1">

                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

                        <style type="text/css">

                            @media screen {

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 400;

                                    src: local("Lato Regular"), local("Lato-Regular"), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 700;

                                    src: local("Lato Bold"), local("Lato-Bold"), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family:  "Lato";

                                    font-style: italic;

                                    font-weight: 400;

                                    src: local("Lato Italic"), local("Lato-Italic"), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: v

                                    font-style: italic;

                                    font-weight: 700;

                                    src: local("Lato Bold Italic"), local("Lato-BoldItalic"), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format("woff");

                                }

                            }

                    

                            /* CLIENT-SPECIFIC STYLES */

                            body,

                            table,

                            td,

                            a {

                                -webkit-text-size-adjust: 100%;

                                -ms-text-size-adjust: 100%;

                            }

                    

                            table,

                            td {

                                mso-table-lspace: 0pt;

                                mso-table-rspace: 0pt;

                            }

                    

                            img {

                                -ms-interpolation-mode: bicubic;

                            }

                    

                            /* RESET STYLES */

                            img {

                                border: 0;

                                height: auto;

                                line-height: 100%;

                                outline: none;

                                text-decoration: none;

                            }

                    

                            table {

                                border-collapse: collapse !important;

                            }

                    

                            body {

                                height: 100% !important;

                                margin: 0 !important;

                                padding: 0 !important;

                                width: 100% !important;

                            }

                    

                            /* iOS BLUE LINKS */

                            a[x-apple-data-detectors] {

                                color: inherit !important;

                                text-decoration: none !important;

                                font-size: inherit !important;

                                font-family: inherit !important;

                                font-weight: inherit !important;

                                line-height: inherit !important;

                            }

                    

                            /* MOBILE STYLES */

                            @media screen and (max-width:600px) {

                                h1 {

                                    font-size: 32px !important;

                                    line-height: 32px !important;

                                }

                            }

                    

                            /* ANDROID CENTER FIX */

                            div[style*="margin: 16px 0;"] {

                                margin: 0 !important;

                            }

                        </style>

                    </head> 

                    <body style=" margin: 0 !important; padding: 0 !important;">

                       

    <table border="0" cellpadding="0" cellspacing="0" width="100%">

        <!-- LOGO -->

        

        <tr>

            <td  align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">

                            <h1 style="font-size: 35px; font-weight: 400; margin: 2;">Thesis Updates</h1>

                        </td>

                    </tr>

                </table>

            </td>

        </tr>

        <tr>

            <td " align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

                            <p style="margin: 0;">' . $this->input->post('rejection_remark_teacher') . ' on ' . date("d/m/Y") . '. Please re upload to continue.</p>

                            <br>

                            

                        </td>

                    </tr> 

                    <tr></tr>

                </table>

            </td>

        </tr>

         

         

    </table>

</body>



</html>

			';

		$this->load->library('email');

		$this->email->from(no_reply_mail, no_reply_name);

		$this->email->to($result->email);

		$this->email->subject('Thesis Updates');

		$this->email->message($message);

		$this->email->set_mailtype('html');

		if ($this->email->send()) {
		} else {
		}

		return true;
	}

	public function set_reject_synopsis()
	{

		$data = array(

			'remarks' => $this->input->post('rejection_remark_teacher'),

			'synopsis_status' => '3',

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_synopsis', $data);



		$this->db->select('tbl_student.email');

		$this->db->where('tbl_synopsis.id', $this->input->post('id'));

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$result = $this->db->get('tbl_synopsis');

		$result = $result->row();



		$message = '

			<!DOCTYPE html>

                <html>

                    <head>

                        <title></title>

                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

                        <meta name="viewport" content="width=device-width, initial-scale=1">

                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

                        <style type="text/css">

                            @media screen {

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 400;

                                    src: local("Lato Regular"), local("Lato-Regular"), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 700;

                                    src: local("Lato Bold"), local("Lato-Bold"), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family:  "Lato";

                                    font-style: italic;

                                    font-weight: 400;

                                    src: local("Lato Italic"), local("Lato-Italic"), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: v

                                    font-style: italic;

                                    font-weight: 700;

                                    src: local("Lato Bold Italic"), local("Lato-BoldItalic"), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format("woff");

                                }

                            }

                    

                            /* CLIENT-SPECIFIC STYLES */

                            body,

                            table,

                            td,

                            a {

                                -webkit-text-size-adjust: 100%;

                                -ms-text-size-adjust: 100%;

                            }

                    

                            table,

                            td {

                                mso-table-lspace: 0pt;

                                mso-table-rspace: 0pt;

                            }

                    

                            img {

                                -ms-interpolation-mode: bicubic;

                            }

                    

                            /* RESET STYLES */

                            img {

                                border: 0;

                                height: auto;

                                line-height: 100%;

                                outline: none;

                                text-decoration: none;

                            }

                    

                            table {

                                border-collapse: collapse !important;

                            }

                    

                            body {

                                height: 100% !important;

                                margin: 0 !important;

                                padding: 0 !important;

                                width: 100% !important;

                            }

                    

                            /* iOS BLUE LINKS */

                            a[x-apple-data-detectors] {

                                color: inherit !important;

                                text-decoration: none !important;

                                font-size: inherit !important;

                                font-family: inherit !important;

                                font-weight: inherit !important;

                                line-height: inherit !important;

                            }

                    

                            /* MOBILE STYLES */

                            @media screen and (max-width:600px) {

                                h1 {

                                    font-size: 32px !important;

                                    line-height: 32px !important;

                                }

                            }

                    

                            /* ANDROID CENTER FIX */

                            div[style*="margin: 16px 0;"] {

                                margin: 0 !important;

                            }

                        </style>

                    </head> 

                    <body style=" margin: 0 !important; padding: 0 !important;">

                       

    <table border="0" cellpadding="0" cellspacing="0" width="100%">

        <!-- LOGO -->

        

        <tr>

            <td  align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">

                            <h1 style="font-size: 35px; font-weight: 400; margin: 2;">Synopsis Updates</h1>

                        </td>

                    </tr>

                </table>

            </td>

        </tr>

        <tr>

            <td " align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

                            <p style="margin: 0;">' . $this->input->post('rejection_remark_teacher') . ' on ' . date("d/m/Y") . '. Please re upload to continue.</p>

                            <br>

                            

                        </td>

                    </tr> 

                    <tr></tr>

                </table>

            </td>

        </tr>

         

         

    </table>

</body>



</html>

			';

		$this->load->library('email');

		$this->email->from(no_reply_mail, no_reply_name);

		$this->email->to($result->email);

		$this->email->subject('Synopsis Updates');

		$this->email->message($message);

		$this->email->set_mailtype('html');

		if ($this->email->send()) {
		} else {
		}

		return true;
	}

	public function set_reject_abstract()
	{

		$data = array(

			'remark' => $this->input->post('rejection_remark_teacher'),

			'report_status' => '2',
		);
		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_abstract', $data);

		$this->db->select('tbl_student.email');

		$this->db->where('tbl_abstract.id', $this->input->post('id'));

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$result = $this->db->get('tbl_abstract');

		$result = $result->row();


		$message = '

			<!DOCTYPE html>

                <html>

                    <head>

                        <title></title>

                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

                        <meta name="viewport" content="width=device-width, initial-scale=1">

                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

                        <style type="text/css">

                            @media screen {

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 400;

                                    src: local("Lato Regular"), local("Lato-Regular"), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: "Lato";

                                    font-style: normal;

                                    font-weight: 700;

                                    src: local("Lato Bold"), local("Lato-Bold"), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family:  "Lato";

                                    font-style: italic;

                                    font-weight: 400;

                                    src: local("Lato Italic"), local("Lato-Italic"), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format("woff");

                                }

                    

                                @font-face {

                                    font-family: v

                                    font-style: italic;

                                    font-weight: 700;

                                    src: local("Lato Bold Italic"), local("Lato-BoldItalic"), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format("woff");

                                }

                            }

                    

                            /* CLIENT-SPECIFIC STYLES */

                            body,

                            table,

                            td,

                            a {

                                -webkit-text-size-adjust: 100%;

                                -ms-text-size-adjust: 100%;

                            }

                    

                            table,

                            td {

                                mso-table-lspace: 0pt;

                                mso-table-rspace: 0pt;

                            }

                    

                            img {

                                -ms-interpolation-mode: bicubic;

                            }

                    

                            /* RESET STYLES */

                            img {

                                border: 0;

                                height: auto;

                                line-height: 100%;

                                outline: none;

                                text-decoration: none;

                            }

                    

                            table {

                                border-collapse: collapse !important;

                            }

                    

                            body {

                                height: 100% !important;

                                margin: 0 !important;

                                padding: 0 !important;

                                width: 100% !important;

                            }

                    

                            /* iOS BLUE LINKS */

                            a[x-apple-data-detectors] {

                                color: inherit !important;

                                text-decoration: none !important;

                                font-size: inherit !important;

                                font-family: inherit !important;

                                font-weight: inherit !important;

                                line-height: inherit !important;

                            }

                    

                            /* MOBILE STYLES */

                            @media screen and (max-width:600px) {

                                h1 {

                                    font-size: 32px !important;

                                    line-height: 32px !important;

                                }

                            }

                    

                            /* ANDROID CENTER FIX */

                            div[style*="margin: 16px 0;"] {

                                margin: 0 !important;

                            }

                        </style>

                    </head> 

                    <body style=" margin: 0 !important; padding: 0 !important;">

                       

    <table border="0" cellpadding="0" cellspacing="0" width="100%">

        <!-- LOGO -->

        

        <tr>

            <td  align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">

                            <h1 style="font-size: 35px; font-weight: 400; margin: 2;">Abstract Report Updates</h1>

                        </td>

                    </tr>

                </table>

            </td>

        </tr>

        <tr>

            <td " align="center" style="padding: 0px 10px 0px 10px;">

                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <tr>

                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;">

                            <p style="margin: 0;">' . $this->input->post('rejection_remark_teacher') . ' on ' . date("d/m/Y") . '. Please re upload to continue.</p>

                            <br>

                            

                        </td>

                    </tr> 

                    <tr></tr>

                </table>

            </td>

        </tr>

         

         

    </table>

</body>



</html>

			';

		$this->load->library('email');

		$this->email->from(no_reply_mail, no_reply_name);

		$this->email->to($result->email);

		$this->email->subject('Synopsis Updates');

		$this->email->message($message);

		$this->email->set_mailtype('html');

		if ($this->email->send()) {
		} else {
		}



		return true;
	}

	public function get_complete_thesis_list($length, $start, $search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->result();
	}

	public function get_complete_thesis_list_count($search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_thesis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->num_rows();
	}

	public function get_rejected_thesis_list($length, $start, $search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '1');

		if ($search != "") {

			$this->db->group_start();
			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('id', 'DESC');

		$this->db->limit($length, $start);


		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->result();
	}

	public function get_rejected_thesis_list_count($search)
	{

		$this->db->select('tbl_thesis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_thesis.is_deleted', '0');

		$this->db->where('tbl_thesis.thesis_status', '1');

		if ($search != "") {

			$this->db->group_start();
			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_thesis.thesis_title', $search);

			$this->db->or_like('tbl_thesis.paper_journal1', $search);

			$this->db->or_like('tbl_thesis.softcopy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_thesis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_thesis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_thesis');

		return $result->num_rows();
	}

	public function get_new_synopsis_list($length, $start, $search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where('tbl_synopsis.synopsis_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->order_by('tbl_synopsis.id', 'DESC');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_synopsis');

		return $result->result();
	}

	public function get_new_synopsis_list_count($search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where('tbl_synopsis.synopsis_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_synopsis');

		return $result->num_rows();
	}

	public function get_rejected_synopsis_list($length, $start, $search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where('tbl_synopsis.synopsis_status', '3');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_synopsis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_synopsis');

		return $result->result();
	}

	public function get_rejected_synopsis_list_count($search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where('tbl_synopsis.synopsis_status', '3');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_synopsis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_synopsis');

		return $result->num_rows();
	}

	public function get_single_synopsis()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('status', '1');

		$this->db->where('id', $this->uri->segment(2));

		$result = $this->db->get('tbl_synopsis');

		return $result->row();
	}

	public function get_active_guide_synopsis_list()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('status', '1');

		$this->db->where('appliation_status', '1');

		$result = $this->db->get('tbl_guide_application');

		return $result->result();
	}

	public function get_update_synopsis($file1)
	{

		if ($file1 == "") {

			$file1 = $this->input->post("soft_copy");
		}
		$data = array(

			'thesis_title'	  => $this->input->post('thesis_title'),

			'soft_copy'       => $file1,

			'guide_id'        => $this->input->post('guide'),

			'synopsis_status' => $this->input->post('synopsis_status'),

			'remarks' 		  => $this->input->post('remarks'),

			'issue_date'      => date("Y-m-d", strtotime($this->input->post('issue_date'))),

			"signature_id" 	  => $this->input->post('signature'),
		);
		// echo"<pre>";print_r($data);exit;
		// $this->db->where('id',$this->input->post('id'));

		$this->db->where('id', $this->uri->segment(2));

		$this->db->update('tbl_synopsis', $data);
		return 1;
	}

	public function get_complete_synopsis_list($length, $start, $search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where_in('tbl_synopsis.synopsis_status', array('0', '1'));

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_synopsis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_synopsis');

		return $result->result();
	}

	public function get_complete_synopsis_list_count($search)
	{

		$this->db->select('tbl_synopsis.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_synopsis.is_deleted', '0');

		$this->db->where_in('tbl_synopsis.synopsis_status', array('0', '1'));


		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->or_like('tbl_synopsis.thesis_title', $search);

			$this->db->or_like('tbl_synopsis.soft_copy', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_synopsis.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_synopsis.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_synopsis');

		return $result->num_rows();
	}

	public function get_progress_report_list($length, $start, $search)
	{

		$this->db->select('tbl_progress_report.*,tbl_student.student_name,tbl_student.enrollment_number');

		$this->db->where('tbl_progress_report.is_deleted', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_progress_report.progress_report', $search);

			$this->db->or_like('tbl_progress_report.remark', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_progress_report.id', 'DESC');

		$this->db->limit($length, $start);

		//$this->db->where('thesis_status','1');

		//$this->db->where('thesis_status','2');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_progress_report.student_id');

		$result = $this->db->get('tbl_progress_report');

		return $result->result();
	}

	public function get_progress_report_list_count($search)
	{

		$this->db->select('tbl_progress_report.*,tbl_student.student_name,tbl_student.enrollment_number');

		$this->db->where('tbl_progress_report.is_deleted', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_progress_report.progress_report', $search);

			$this->db->or_like('tbl_progress_report.remark', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->group_end();
		}

		$this->db->join('tbl_student', 'tbl_student.id = tbl_progress_report.student_id');

		$result = $this->db->get('tbl_progress_report');

		return $result->num_rows();
	}

	public function get_abstract_report_list($length, $start, $search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '0');



		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_abstract');

		return $result->result();
	}

	public function get_abstract_report_list_count($search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_abstract');

		return $result->num_rows();
	}

	public function get_approved_abstract_report_list($length, $start, $search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_abstract');

		return $result->result();
	}

	public function get_approved_abstract_report_list_count($search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '1');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_abstract');

		return $result->num_rows();
	}

	public function get_rejected_abstract_report_list($length, $start, $search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_abstract');

		return $result->result();
	}

	public function get_rejected_abstract_report_list_count($search)
	{

		$this->db->select('tbl_abstract.*,tbl_student.student_name,tbl_student.enrollment_number,tbl_student.email,tbl_student.mobile,tbl_course.course_name,tbl_stream.stream_name,tbl_center.center_name,tbl_session.session_name');

		$this->db->where('tbl_abstract.is_deleted', '0');

		$this->db->where('tbl_abstract.report_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_abstract.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_abstract.student_id');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$result = $this->db->get('tbl_abstract');

		return $result->num_rows();
	}

	public function get_single_abstract_report()
	{

		$this->db->where('id', $this->uri->segment(2));

		$result = $this->db->get('tbl_abstract');

		return $result->row();
	}

	public function get_update_abstract($userfile1)
	{

		if ($userfile1 == "") {

			$userfile1 = $this->input->post('upload_report');
		}
		$data = array(

			'upload_report' => $userfile1,

			'report_status' => $this->input->post('report_status'),

			'remark' => $this->input->post('remark'),

		);
		// echo "<pre>";print_r($data);exit;

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_abstract', $data);

		return true;
	}

	public function hold_login()
	{

		$data = array(

			'hold_login' => '1'

		);

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function activate_login()
	{

		$data = array(

			'hold_login' => '0'

		);

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function hold_login_single()
	{

		$data = array(

			'hold_login' => '1',

			'hold_remark' => $this->input->post('hold_remark'),

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function activate_login_single()
	{

		$data = array(

			'hold_login' => '0',

			'hold_remark' => $this->input->post('hold_remark'),

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function pending_student_remark()
	{

		$data = array(

			'pending_remark' => $this->input->post('pending_remark'),

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function get_phd_exam_student_ans_book_test_name()
	{

		/*$this->db->select('tbl_test_phd_students.*,tbl_test_title_for_phd.test_name');

		$this->db->where('tbl_test_phd_students.is_deleted','0');

		$this->db->where('tbl_test_phd_students.student_email',$this->uri->segment(2));

		$this->db->where('tbl_test_phd_students.test_id',$this->uri->segment(3));

		$this->db->join('tbl_test_title_for_phd','tbl_test_title_for_phd.id = tbl_test_phd_students.test_id');

		$result = $this->db->get('tbl_test_phd_students');

		return $result->row();*/

		// echo "<pre>";print_r($this->uri->segment(2));exit;
		$this->db->select('tbl_phd_entrance_details.*,tbl_test_title_for_phd.test_name');
		$this->db->where('tbl_phd_entrance_details.is_deleted', '0');
		$this->db->where('tbl_phd_entrance_details.student_exam_id', $this->uri->segment(2));
		// $this->db->where('tbl_phd_entrance_details.id',$this->uri->segment(2)); 
		$this->db->join('tbl_test_title_for_phd', 'tbl_test_title_for_phd.id = tbl_phd_entrance_details.test_id');
		$result = $this->db->get('tbl_phd_entrance_details');
		return $result->result();

		// $result = $result->result();
		// echo "<pre>";print_r($result);exit;
	}

	public function get_entrance_question_details($id)
	{

		$this->db->where('id', $id);

		$result = $this->db->get('tbl_question_ans');

		return $result->row();
	}

	public function get_enrolled_status_phd($email_id, $father_name, $mobile_number)
	{

		//$this->db->where('email',$email_id); 

		//$this->db->where('father_name',$father_name); 

		$this->db->where('mobile', $mobile_number);

		$this->db->where('course_id', '23');

		$this->db->where('admission_status !=', '0');

		$result = $this->db->get('tbl_student');

		$result = $result->row();

		if (!empty($result)) {

			return 1;
		} else {

			return 0;
		}
	}

	public function send_phd_result_mail()
	{

		$this->db->where('id', $this->uri->segment(2));

		$result = $this->db->get('tbl_phd_registration_form');

		$result = $result->row();

		if (!empty($result)) {

			$this->load->library('email');

			$config['protocol'] = 'sendmail';

			$config['mailpath'] = '/usr/sbin/sendmail';

			$config['charset'] = 'iso-8859-1';

			$config['wordwrap'] = TRUE;

			$this->email->initialize($config);

			$this->email

				->from(no_reply_mail)

				->to($result->email_id)

				->subject("Entrance Exam Result |" . no_reply_name)

				->message('Dear Scholar,<br>
				<br>We hope this message finds you well. We are pleased to inform you that the results for the recent entrance examination have been finalized, and we are ready to share them with you.
				<br>
				After a thorough evaluation of your performance, we are pleased to announce that you have successfully cleared the entrance exam.
				<br><br>Best Regards,<br>IT Team
				')

				->set_mailtype('html');

			if ($this->email->send()) {

				return true;
			} else {

				return true;
			}
		} else {

			return false;
		}
	}

	public function get_enquiry_head($length, $start, $search)
	{

		$this->db->where('is_deleted', '0');



		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('head_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('head_name', 'ASC');

		$this->db->limit($length, $start);

		$result = $this->db->get('tbl_followup_heads');

		return $result->result();
	}

	public function get_enquiry_head_count($search)
	{

		$this->db->where('is_deleted', '0');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('head_name', $search);

			$this->db->group_end();
		}

		$result = $this->db->get('tbl_followup_heads');

		return $result->num_rows();
	}

	public function set_enquiry_head()
	{

		$data = array(

			'head_name' => $this->input->post('head_name'),

		);

		if ($this->input->post('id') == "") {

			$date = array(

				'created_on' => date("Y-m-d H:i:s")

			);

			$new_arr = array_merge($data, $date);

			$this->db->insert('tbl_followup_heads', $new_arr);

			return 0;
		} else {

			$this->db->where('id', $this->input->post('id'));

			$this->db->update('tbl_followup_heads', $data);

			return 1;
		}
	}

	public function get_single_followup_head()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('id', $this->uri->segment(2));

		$result = $this->db->get('tbl_followup_heads');

		return $result->row();
	}

	public function get_all_admission_ajax_pulp($length, $start, $search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.course_for', '1');

		$this->db->where('tbl_student.admission_status !=', '0');

		$this->db->where('tbl_student.admission_status !=', '2');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.enrollment_date', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}

	public function get_all_admission_count_pulp($search)
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.course_for', '1');

		$this->db->where('tbl_student.admission_status !=', '0');

		$this->db->where('tbl_student.admission_status !=', '2');

		if ($this->input->post('start_date') != "") {

			$this->db->where('tbl_student.enrollment_date >=', date("Y-m-d", strtotime($this->input->post('start_date'))));
		}

		if ($this->input->post('end_date') != "") {

			$this->db->where('tbl_student.enrollment_date <=', date("Y-m-d", strtotime($this->input->post('end_date'))));
		}

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.student_name', $search);

			$this->db->or_like('tbl_student.father_name', $search);

			$this->db->or_like('tbl_student.mother_name', $search);

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student.mobile', $search);

			$this->db->or_like('tbl_student.email', $search);

			$this->db->or_like('tbl_id_management.id_name', $search);

			$this->db->or_like('tbl_student.id_number', $search);

			$this->db->or_like('tbl_student.gender', $search);

			$this->db->or_like('tbl_student.category', $search);

			$this->db->or_like('tbl_student.address', $search);

			$this->db->or_like('tbl_student.nationality', $search);

			$this->db->or_like('countries.name', $search);

			$this->db->or_like('states.name', $search);

			$this->db->or_like('cities.name', $search);

			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_center.center_name', $search);

			$this->db->or_like('tbl_session.session_name', $search);

			$this->db->or_like('tbl_faculty.faculty_name', $search);

			$this->db->or_like('tbl_course_type.course_type', $search);

			$this->db->or_like('tbl_course.course_name', $search);

			$this->db->or_like('tbl_stream.stream_name', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student.id', 'ASC');

		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}

	public function set_refund()
	{

		if ($_FILES['userfile']['name'] != "") {

			$photo = $this->Digitalocean_model->upload_photo($filename = "userfile", $path = "images/refund_docs/");
		} else {

			$photo = $this->input->post('old_userfile');
		}

		$data = array(

			'student_id' 		=> $this->input->post('student_id'),

			'account_number' 	=> $this->input->post('account_number'),

			'account_name' 		=> $this->input->post('account_name'),

			'ifsc' 				=> $this->input->post('ifsc'),

			'reference_id' 		=> $this->input->post('reference_id'),

			'refund_amount' 	=> $this->input->post('refund_amount'),

			'remark' 			=> $this->input->post('remark'),

			'document' 			=> $photo,

			'date' 				=> date("Y-m-d", strtotime($this->input->post('date'))),

		);



		$data_refund = array(

			'admission_status' 	=> '5',

		);

		if ($this->input->post('id') == "") {

			$date = array(

				'created_on' => date("Y-m-d H:i:s")

			);

			$new_arr = array_merge($data, $date);

			$this->db->insert('tbl_student_refund', $new_arr);

			$this->db->where('id', $this->input->post('student_id'));

			$this->db->update('tbl_student', $data_refund);

			return 0;
		} else {

			$this->db->where('id', $this->input->post('id'));

			$this->db->update('tbl_student_refund', $data);

			$this->db->where('id', $this->input->post('student_id'));

			$this->db->update('tbl_student', $data_refund);

			return 1;
		}
	}

	public function get_single_refund()
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('student_id', $this->uri->segment(2));

		$result = $this->db->get('tbl_student_refund');

		return $result->row();
	}

	public function get_single_refund_research()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('research_id', $this->uri->segment(2));
		$result = $this->db->get('tbl_research_refund');
		return $result->row();
		// $result = $result->row(); 
		// echo "<pre>";print_r($result);exit;
	}


	public function get_all_phd_registration()
	{
		$this->db->select('tbl_phd_registration_form.*');
		$this->db->where('tbl_phd_registration_form.is_deleted', '0');
		$this->db->where('tbl_phd_registration_form.payment_status', '1');
		$this->db->where('tbl_phd_registration_form.id', $this->uri->segment(2));
		$result = $this->db->get('tbl_phd_registration_form');
		return $result->row();
	}

	public function get_all_phd_registration_refund()
	{
		$this->db->select('tbl_phd_registration_form.*');
		$this->db->where('tbl_phd_registration_form.is_deleted', '0');
		$this->db->where('tbl_phd_registration_form.payment_status', '0');
		$this->db->where('tbl_phd_registration_form.id', $this->uri->segment(2));
		$result = $this->db->get('tbl_phd_registration_form');
		return $result->row();
	}

	public function get_all_phd_registration_student_refunded()
	{
		$this->db->select('tbl_phd_registration_form.*');
		$this->db->where('tbl_phd_registration_form.is_deleted', '0');
		$this->db->where('tbl_phd_registration_form.payment_status', '2');
		$this->db->where('tbl_phd_registration_form.id', $this->uri->segment(2));
		$result = $this->db->get('tbl_phd_registration_form');
		return $result->row();
	}

	public function get_all_admission_ajax_refund($length, $start, $search)
	{

		$this->db->select('tbl_student_refund.*,tbl_student.id,tbl_student.enrollment_number,tbl_student.id as reg_id,tbl_student.admission_status,tbl_student.verified_status');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.course_for', '0');

		$this->db->where('tbl_student.admission_status', '5');

		// if($this->input->post('start_date')!=""){

		// 	$this->db->where('tbl_student.enrollment_date >=',date("Y-m-d",strtotime($this->input->post('start_date'))));  

		// }

		// if($this->input->post('end_date')!=""){

		// 	$this->db->where('tbl_student.enrollment_date <=',date("Y-m-d",strtotime($this->input->post('end_date'))));  

		// }

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student_refund.account_number', $search);

			$this->db->or_like('tbl_student_refund.account_name', $search);

			$this->db->or_like('tbl_student_refund.ifsc', $search);

			$this->db->or_like('tbl_student_refund.reference_id', $search);

			$this->db->or_like('tbl_student_refund.refund_amount', $search);

			$this->db->or_like('tbl_student_refund.remark', $search);

			$this->db->or_like('tbl_student_refund.date', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student_refund.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_refund.student_id');

		$result = $this->db->get('tbl_student_refund');

		return $result->result();
	}

	public function get_all_admission_count_refund($search)
	{

		$this->db->select('tbl_student_refund.*,tbl_student.id,tbl_student.enrollment_number,tbl_student.id as reg_id,tbl_student.admission_status,tbl_student.verified_status');

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.verified_status', '1');

		$this->db->where('tbl_student.course_for', '0');

		$this->db->where('tbl_student.admission_status', '5');

		//$this->db->where('tbl_student.admission_status !=','2');



		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_student.enrollment_number', $search);

			$this->db->or_like('tbl_student_refund.account_number', $search);

			$this->db->or_like('tbl_student_refund.account_name', $search);

			$this->db->or_like('tbl_student_refund.ifsc', $search);

			$this->db->or_like('tbl_student_refund.reference_id', $search);

			$this->db->or_like('tbl_student_refund.refund_amount', $search);

			$this->db->or_like('tbl_student_refund.remark', $search);

			$this->db->or_like('tbl_student_refund.date', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_student_refund.id', 'DESC');

		$this->db->join('tbl_student', 'tbl_student.id = tbl_student_refund.student_id');

		$result = $this->db->get('tbl_student_refund');

		return $result->num_rows();
	}

	public function set_refund_refresh()
	{

		if ($_FILES['userfile']['name'] != "") {

			$photo = $this->Digitalocean_model->upload_photo($filename = "userfile", $path = "images/refund_docs/");
		} else {

			$photo = $this->input->post('old_userfile');
		}

		$data = array(

			'research_id' 			=> $this->input->post('research_id'),

			'account_number' 	=> $this->input->post('account_number'),

			'account_name' 		=> $this->input->post('account_name'),

			'ifsc' 				=> $this->input->post('ifsc'),

			'reference_id' 		=> $this->input->post('reference_id'),

			'refund_amount' 	=> $this->input->post('refund_amount'),

			'remark' 			=> $this->input->post('remark'),

			'document' 			=> $photo,

			'date' 				=> date("Y-m-d", strtotime($this->input->post('date'))),

		);

		$data_refund = array(

			'payment_status' 	=> '2',

		);

		if ($this->input->post('id') == "") {

			$date = array(

				'created_on' => date("Y-m-d H:i:s")

			);

			$new_arr = array_merge($data, $date);

			$this->db->insert('tbl_research_refund', $new_arr);

			$this->db->where('id', $this->input->post('research_id'));

			$this->db->update('tbl_phd_registration_form', $data_refund);

			return 0;
		} else {

			$this->db->where('id', $this->input->post('id'));

			$this->db->update('tbl_research_refund', $data);

			$this->db->where('id', $this->input->post('research_id'));

			$this->db->update('tbl_phd_registration_form', $data_refund);

			return 1;
		}
	}



	public function get_all_phd_registration_refunded($length, $start, $search)
	{

		$this->db->select('tbl_research_refund.*,tbl_phd_registration_form.student_name');

		$this->db->where('tbl_research_refund.is_deleted', '0');

		$this->db->where('tbl_phd_registration_form.payment_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_phd_registration_form.student_name', $search);

			//$this->db->or_like('tbl_phd_registration_form.enrollment_number',$search);

			$this->db->or_like('tbl_research_refund.account_number', $search);

			$this->db->or_like('tbl_research_refund.account_name', $search);

			$this->db->or_like('tbl_research_refund.ifsc', $search);

			$this->db->or_like('tbl_research_refund.reference_id', $search);

			$this->db->or_like('tbl_research_refund.refund_amount', $search);

			$this->db->or_like('tbl_research_refund.remark', $search);

			$this->db->or_like('tbl_research_refund.date', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_research_refund.id', 'DESC');

		$this->db->limit($length, $start);

		$this->db->join('tbl_phd_registration_form', 'tbl_phd_registration_form.id = tbl_research_refund.research_id');

		$result = $this->db->get('tbl_research_refund');

		return $result->result();
	}

	public function get_all_phd_registration_refunded_count($search)
	{

		$this->db->select('tbl_research_refund.*,tbl_phd_registration_form.student_name');

		$this->db->where('tbl_research_refund.is_deleted', '0');

		$this->db->where('tbl_phd_registration_form.payment_status', '2');

		if ($search != "") {

			$this->db->group_start();

			$this->db->or_like('tbl_phd_registration_form.student_name', $search);

			//$this->db->or_like('tbl_phd_registration_form.enrollment_number',$search);

			$this->db->or_like('tbl_research_refund.account_number', $search);

			$this->db->or_like('tbl_research_refund.account_name', $search);

			$this->db->or_like('tbl_research_refund.ifsc', $search);

			$this->db->or_like('tbl_research_refund.reference_id', $search);

			$this->db->or_like('tbl_research_refund.refund_amount', $search);

			$this->db->or_like('tbl_research_refund.remark', $search);

			$this->db->or_like('tbl_research_refund.date', $search);

			$this->db->group_end();
		}

		$this->db->order_by('tbl_research_refund.id', 'DESC');

		$this->db->join('tbl_phd_registration_form', 'tbl_phd_registration_form.id = tbl_research_refund.research_id');

		$result = $this->db->get('tbl_research_refund');

		return $result->num_rows();
	}

	public function get_verified_student()
	{
		// $this->db->where('center_id','1');
		$this->db->where('enrollment_number', $this->input->post('enrollment_number'));

		$result = $this->db->get('tbl_student');

		$result = $result->row();
		if (!empty($result)) {
			redirect('admin_set_reregistration_form/' . $result->id);
		} else {
			$this->session->set_flashdata('message', 'Please enter valid enrollment number');
			redirect('admin_set_reregistration_form');
		}
	}

	public function get_student_for_rr()
	{
		// echo "<pre>";print_r($this->uri->segment(2));exit;
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name,tbl_center.center_name');

		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.course_id !=', '23'); //
		$this->db->where('tbl_student.admission_status', '1');

		$this->db->where('tbl_student.id', $this->uri->segment(2));
		// $this->db->where('tbl_student.center_id','1'); 
		// $this->db->where('tbl_student.enrollment_number',$this->input->post('enrollment_number'));
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');

		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');

		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');

		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');

		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->join('countries', 'countries.id = tbl_student.country');

		$this->db->join('states', 'states.id = tbl_student.state');

		$this->db->join('cities', 'cities.id = tbl_student.city');

		$result = $this->db->get('tbl_student');
		return $result->row();

		// $result = $result->row();
		// if(!empty($result)){
		// 	$this->db->select('tbl_examination_form .*');
		// 	$this->db->where('is_deleted','0');
		// 	$this->db->where('status','1');
		// 	$this->db->where('tbl_examination_form.student_id',$result->id);
		// 	$result = $this->db->get('tbl_examination_form');
		// 	$result = $result->row();
		// }
	}

	public function get_exam_form_check_new($id, $year)
	{
		$this->db->select('tbl_examination_form.*,tbl_student.id');
		$this->db->where('tbl_examination_form.is_deleted', '0');
		$this->db->where('tbl_examination_form.status', '1');
		$this->db->where('tbl_examination_form.student_id', $id);
		$this->db->join('tbl_student', 'tbl_student.id = tbl_examination_form.student_id', 'left');
		$this->db->where('tbl_examination_form.year_sem', $year);
		$result = $this->db->get('tbl_examination_form');
		return $result->row();
	}

	public function get_exam_fees($session, $course, $stream)
	{
		$this->db->where('tbl_fees_realtion.session_id', $session);
		$this->db->where('tbl_fees_realtion.course_id', $course);
		$this->db->where('tbl_fees_realtion.stream_id', $stream);
		$this->db->order_by('tbl_fees_realtion.id', 'DESC');
		$result = $this->db->get('tbl_fees_realtion');
		return $result->row();
	}


	public function set_re_registration()
	{

		$data = array(

			'year_sem' => $this->input->post('year_sem')

		);

		$this->db->where('id', $this->input->post('id'));

		$this->db->update('tbl_student', $data);

		$result =  $this->Web_model->get_single_student($this->input->post('id'));

		$maintain_data = array(

			"student_id"		=> $result->id,

			"enrollment_number"	=> $result->enrollment_number,

			"previous_year_sem"	=> $result->year_sem - 1,

			"current_year_sem"	=> $result->year_sem,

			"course_mode"		=> $result->course_mode,

			"created_on"		=> date("Y-m-d H:i:s"),

			"payment_status"	=> '1',

		);

		$this->db->insert("tbl_re_registered_student", $maintain_data);

		return true;
	}

	public function get_all_session_list()
	{

		$this->db->where('is_deleted', '0');

		$result = $this->db->get('tbl_session');

		return $result->result();
	}

	public function all_activate_center_wise()
	{

		$data = array(

			'hold_login' => '0'

		);

		if ($this->input->post('center') != "All") {

			$this->db->where('center_id', $this->input->post('center'));
		}

		$this->db->update('tbl_student', $data);

		return true;
	}

	public function all_hold_center_wise()
	{

		$data = array(

			'hold_login' => '1'

		);

		if ($this->input->post('center') != "All") {

			$this->db->where('center_id', $this->input->post('center'));
		}

		$this->db->update('tbl_student', $data);

		return true;
	}



	public function old_admission_check($print)
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('student_name', $print->student_name);

		$this->db->where('father_name', $print->father_name);

		$this->db->where('mother_name', $print->mother_name);

		$this->db->where('email', $print->email);

		$this->db->where('admission_status', '1');

		$result = $this->db->get('tbl_student');

		return $result->num_rows();
	}



	public function old_admission_check_new($print)
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('student_name', $print->student_name);

		$this->db->where('father_name', $print->father_name);

		$this->db->where('mother_name', $print->mother_name);

		$this->db->where('email', $print->email);

		$this->db->where('admission_status', '1');

		$result = $this->db->get('tbl_student');

		return $result->result();
	}



	public function get_old_course($old_check_result)
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('id', $old_check_result->course_id);

		$result = $this->db->get('tbl_course');

		return $result->row();
	}



	public function get_old_stream($old_check_result)
	{

		$this->db->where('is_deleted', '0');

		$this->db->where('id', $old_check_result->stream_id);

		$result = $this->db->get('tbl_stream');

		return $result->row();
	}

	public function get_student_all_activities()
	{

		$enrollment = 0;

		$activity = array();

		$this->db->select('student_name,created_on,enrollment_date,enrollment_number');

		$this->db->where('id', $this->uri->segment(2));

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$admission = $this->db->get('tbl_student');

		$admission = $admission->row();

		if (!empty($admission)) {

			$enrollment = $admission->enrollment_number;

			$activity[] = array(

				'title'				=> 'ADMISSION PROCESS',

				'created_on' 		=> $admission->created_on,

				'description' 		=> $admission->student_name . ' has applied for admission',

				'remark' 			=> '',

				'single_file' 		=> '',

				'multiple_files'	=> '',

				'link'				=> '',
				'edit_status'		=> '0',
				'id'				=> '0',
				'file'				=> '0',
			);
		}

		$this->db->where('enrollment_number', $enrollment);
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$document_verification = $this->db->get('tbl_document_verification');
		$document_verification = $document_verification->result();
		if (!empty($document_verification)) {
			foreach ($document_verification as $document_verification_result) {
				if ($document_verification_result->is_verified == "0") {
					$verified_status = "Not Verified";
				} else {
					$verified_status = "Verified";
				}
				$activity[] = array(
					'title'				=> 'Document Verification',
					'created_on' 		=> $document_verification_result->created_on,
					'description' 		=> $document_verification_result->query,
					'remark' 			=> "Courier Number: " . $document_verification_result->courier_number . '<br>&nbsp;&nbsp; Dispatch Date: ' . $document_verification_result->dispatch_date . "<br>&nbsp;&nbsp; Transaction ID: " . $document_verification_result->transaction_id . "<br>&nbsp;&nbsp; Verified Status: " . $verified_status,
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		if (!empty($admission) && $admission->enrollment_number != "") {

			$activity[] = array(

				'title'				=> 'ADMISSION PROCESS',

				'created_on' 		=> $admission->created_on,

				'description' 		=> $admission->student_name . ' has enrolled',

				'remark' 			=> '',

				'single_file' 		=> '',

				'multiple_files'	=> '',

				'link'				=> '',
				'edit_status'		=> '0',
				'id'				=> '0',
				'file'				=> '',
			);
		}

		$this->db->where('tbl_log.student_id', $this->uri->segment(2));

		$this->db->where('tbl_log.is_deleted', '0');

		$this->db->where('tbl_log.student_type', '0');

		$this->db->order_by('tbl_log.id', 'DESC');

		$log = $this->db->get('tbl_log');

		$log = $log->result();

		if (!empty($log)) {

			foreach ($log as $log_result) {

				$activity[] = array(

					'title'				=> 'GENERAL LOGS',

					'created_on' 		=> $log_result->created_on,

					'description' 		=> $log_result->description,

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('enrollment_number', $enrollment);

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$rti = $this->db->get('tbl_caste_discrimination');

		$rti = $rti->result();

		if (!empty($rti)) {

			foreach ($rti as $rti_result) {

				$replyies = "";

				if ($rti_result->rti_reply != "") {

					$all_rti_reply = explode(',', $rti_result->rti_reply);

					for ($i = 0; $i < count($all_rti_reply) - 1; $i++) {

						if ($all_rti_reply[$i] != "") {

							$replyies .= $this->Digitalocean_model->get_photo('rti_reply/' . $all_rti_reply[$i]) . "@@@";
						}
					}
				}

				$activity[] = array(

					'title'				=> 'RTI',

					'created_on' 		=> $rti_result->created_on,

					'description' 		=> $rti_result->complaint,

					'remark' 			=> $rti_result->rti_reply,

					'single_file' 		=> $this->Digitalocean_model->get_photo('rti_reply/' . $rti_result->file),

					'multiple_files'	=> $replyies,

					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}
		$this->db->where('student_id', $this->uri->segment(2));

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$remarks = $this->db->get('tbl_student_remarks');

		$remarks = $remarks->result();

		if (!empty($remarks)) {

			foreach ($remarks as $remarks_result) {

				$replyies = "";

				if ($remarks_result->file != "") {

					$all_remarks_file = explode(',', $remarks_result->file);

					for ($i = 0; $i < count($all_remarks_file) - 1; $i++) {

						if ($all_remarks_file[$i] != "") {

							$replyies .= $this->Digitalocean_model->get_photo('student_remark_document/' . $all_remarks_file[$i]) . "@@@";
						}
					}
				}

				$activity[] = array(

					'title'				=> 'REMARKS',

					'created_on' 		=> $remarks_result->created_on,

					'description' 		=> $remarks_result->remark,

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> $replyies,

					'link'				=> '',
					'edit_status'		=> '1',
					'id'				=> $remarks_result->id,
					'file'				=> $remarks_result->file,
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$exam = $this->db->get('tbl_examination_form');

		$exam = $exam->result();

		if (!empty($exam)) {

			foreach ($exam as $exam_result) {

				$activity[] = array(

					'title'				=> 'EXAMINATION FORM',

					'created_on' 		=> $exam_result->created_on,

					'description' 		=> $admission->student_name . ' has filled exam form',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',

					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('enrollment_number', $enrollment);

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$transcript = $this->db->get('tbl_transcript');

		$transcript = $transcript->result();

		if (!empty($transcript)) {

			foreach ($transcript as $transcript_result) {

				$activity[] = array(

					'title'				=> 'TRANSCRIPT',

					'created_on' 		=> $transcript_result->created_on,

					'description' 		=> $admission->student_name . ' has applied transcript',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',

					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('enrollment', $enrollment);
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$consolidate = $this->db->get('tbl_consolidated_marksheet');
		$consolidate = $consolidate->result();
		if (!empty($consolidate)) {
			foreach ($consolidate as $consolidate_result) {
				$activity[] = array(
					'title'				=> 'CONSOLIDATE MARKSHEET',
					'created_on' 		=> $consolidate_result->created_on,
					'description' 		=> $admission->student_name . ' has applied consolidated marksheet',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$migration = $this->db->get('tbl_student_migration');

		$migration = $migration->result();

		if (!empty($migration)) {

			foreach ($migration as $migration_result) {

				$activity[] = array(

					'title'				=> 'MIGRATION',

					'created_on' 		=> $migration_result->created_on,

					'description' 		=> $admission->student_name . ' has applied migration',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$transfer = $this->db->get('tbl_student_transfer');

		$transfer = $transfer->result();

		if (!empty($transfer)) {

			foreach ($transfer as $transfer_result) {

				$activity[] = array(

					'title'				=> 'TRANSFER',

					'created_on' 		=> $transfer_result->created_on,

					'description' 		=> $admission->student_name . ' has applied transfer',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$degree = $this->db->get('tbl_student_degree');
		$degree = $degree->result();
		if (!empty($degree)) {

			foreach ($degree as $degree_result) {

				$activity[] = array(

					'title'				=> 'DEGREE',

					'created_on' 		=> $degree_result->created_on,

					'description' 		=> $admission->student_name . ' has applied degree',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$degree = $this->db->get('tbl_student_degree');
		$degree = $degree->result();
		if (!empty($degree)) {

			foreach ($degree as $degree_result) {

				$activity[] = array(

					'title'				=> 'DEGREE',

					'created_on' 		=> $degree_result->created_on,

					'description' 		=> $admission->student_name . ' has applied degree',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$provisional_degree = $this->db->get('tbl_student_provisional_degree');
		$provisional_degree = $provisional_degree->result();
		if (!empty($provisional_degree)) {
			foreach ($provisional_degree as $provisional_degree_result) {
				$activity[] = array(
					'title'				=> 'PROVISIONAL DEGREE',
					'created_on' 		=> $provisional_degree_result->created_on,
					'description' 		=> $admission->student_name . ' has applied provisional degree',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$bonafide = $this->db->get('tbl_bonafide_cer_application');
		$bonafide = $bonafide->result();
		if (!empty($bonafide)) {

			foreach ($bonafide as $bonafide_result) {

				$activity[] = array(

					'title'				=> 'BONAFIDE',

					'created_on' 		=> $bonafide_result->created_on,

					'description' 		=> $admission->student_name . ' has applied bonafide',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$medium_of_instruction = $this->db->get('tbl_medium_instruction_application');
		$medium_of_instruction = $medium_of_instruction->result();
		if (!empty($medium_of_instruction)) {
			foreach ($medium_of_instruction as $medium_of_instruction_result) {
				$activity[] = array(

					'title'				=> 'MEDIUM OF INSTRUCTION',

					'created_on' 		=> $medium_of_instruction_result->created_on,

					'description' 		=> $admission->student_name . ' has applied medium of instruction',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$no_backlog = $this->db->get('tbl_no_backlog_application');
		$no_backlog = $no_backlog->result();
		if (!empty($no_backlog)) {
			foreach ($no_backlog as $no_backlog_result) {
				$activity[] = array(

					'title'				=> 'NO BACKLOG',

					'created_on' 		=> $no_backlog_result->created_on,

					'description' 		=> $admission->student_name . ' has applied no backlog',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$no_split = $this->db->get('tbl_no_split_application');
		$no_split = $no_split->result();
		if (!empty($no_split)) {
			foreach ($no_split as $no_split_result) {
				$activity[] = array(
					'title'				=> 'NO SPLIT',

					'created_on' 		=> $no_split_result->created_on,

					'description' 		=> $admission->student_name . ' has applied no split',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$recommendation = $this->db->get('tbl_student_recommendation_letter');
		$recommendation = $recommendation->result();
		if (!empty($recommendation)) {
			foreach ($recommendation as $recommendation_result) {
				$activity[] = array(
					'title'				=> 'RECOMMENDATION',
					'created_on' 		=> $recommendation_result->created_on,
					'description' 		=> $admission->student_name . ' has applied recommendation letter',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$second_recommendation = $this->db->get('tbl_reccom_letter_application_second');
		$second_recommendation = $second_recommendation->result();
		if (!empty($second_recommendation)) {
			foreach ($second_recommendation as $second_recommendation_result) {
				$activity[] = array(
					'title'				=> 'SECOND RECOMMENDATION',
					'created_on' 		=> $second_recommendation_result->created_on,
					'description' 		=> $admission->student_name . ' has applied second recommendation letter',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$character = $this->db->get('tbl_character_certificate');
		$character = $character->result();
		if (!empty($character)) {
			foreach ($character as $character_result) {
				$activity[] = array(
					'title'				=> 'CHARACTER',
					'created_on' 		=> $character_result->created_on,
					'description' 		=> $admission->student_name . ' has applied character certificate',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$fees = $this->db->get('tbl_student_fees');
		$fees = $fees->result();
		if (!empty($fees)) {
			foreach ($fees as $fees_result) {
				$activity[] = array(
					'title'				=> 'fees',
					'created_on' 		=> $fees_result->created_on,
					'description' 		=> $admission->student_name . ' has added fees ' . $fees_result->total_fees,
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$re_registration = $this->db->get('tbl_re_registered_student');
		$re_registration = $re_registration->result();
		if (!empty($re_registration)) {
			foreach ($re_registration as $re_registration_result) {
				// echo "<pre>";print_r($re_registration_result);exit;
				$activity[] = array(
					'title'				=> 'RE-REGISTRATION',
					'created_on' 		=> $re_registration_result->created_on,
					'description' 		=> $admission->student_name . ' has fill re-registration form for year/semester ' . $re_registration_result->current_year_sem,
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$marksheet = $this->db->get('tbl_marksheet');
		$marksheet = $marksheet->result();
		if (!empty($marksheet)) {
			foreach ($marksheet as $marksheet_result) {
				$activity[] = array(
					'title'				=> 'MARKSHEET',
					'created_on' 		=> $marksheet_result->created_on,
					'description' 		=> $admission->student_name . ' has generate marksheet for year/sem ' . $marksheet_result->year_sem,
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$duplicate_marksheet = $this->db->get('tbl_duplicate_marksheet');
		$duplicate_marksheet = $duplicate_marksheet->result();
		if (!empty($duplicate_marksheet)) {
			foreach ($duplicate_marksheet as $duplicate_marksheet_result) {
				$activity[] = array(
					'title'				=> 'DUPLICATE MARKSHEET',
					'created_on' 		=> $duplicate_marksheet_result->created_on,
					'description' 		=> $admission->student_name . ' has create duplicate marksheet',
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('student_id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->order_by('id', 'DESC');
		$exam_result = $this->db->get('tbl_exam_results');
		$exam_result = $exam_result->result();
		if (!empty($exam_result)) {
			foreach ($exam_result as $exam_result_result) {
				$activity[] = array(
					'title'				=> 'RESULT',
					'created_on' 		=> $exam_result_result->created_on,
					'description' 		=> $admission->student_name . ' has generate result for year/sem ' . $exam_result_result->year_sem,
					'remark' 			=> '',
					'single_file' 		=> '',
					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('enrollment_number', $enrollment);

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$kyc_link = $this->db->get('tbl_regular_kyc_link');

		$kyc_link = $kyc_link->result();

		if (!empty($kyc_link)) {

			foreach ($kyc_link as $kyc_link_result) {

				$activity[] = array(

					'title'				=> 'Video KYC LINK',

					'created_on' 		=> $kyc_link_result->created_on,

					'description' 		=> 'Create a mail link for ' . $admission->student_name,

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',

					'link'				=> 'https://personalkyc.com/start_my_kyc/' . base64_encode($enrollment),
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('enrollment_number', $enrollment);

		$this->db->where('is_deleted', '0');

		$this->db->order_by('id', 'DESC');

		$kyc_link = $this->db->get('tbl_regular_video_kyc');

		$kyc_link = $kyc_link->result();

		if (!empty($kyc_link)) {

			foreach ($kyc_link as $kyc_link_result) {

				$activity[] = array(

					'title'				=> 'Video KYC',

					'created_on' 		=> $kyc_link_result->created_on,

					'description' 		=> 'Video KYC completed by ' . $admission->student_name,

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> 'https://personalkyc.com/uploads/video_kyc/' . $kyc_link_result->video,
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}



		$this->db->where('id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->where('admission_status', '2');
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student');
		$result = $result->result();
		if (!empty($result)) {

			foreach ($result as $result_result) {

				$activity[] = array(

					'title'				=> 'Cancel Admission',

					'created_on' 		=> $result_result->created_on,

					'description' 		=> $admission->student_name . ' has cancel Admission',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}


		$this->db->where('id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->where('admission_status', '3');
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student');
		$result = $result->result();
		if (!empty($result)) {

			foreach ($result as $result_result) {

				$activity[] = array(

					'title'				=> 'Hold Admission',

					'created_on' 		=> $result_result->created_on,

					'description' 		=> $admission->student_name . ' has hold Admission',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}

		$this->db->where('id', $this->uri->segment(2));
		$this->db->where('is_deleted', '0');
		$this->db->where('admission_status', '5');
		$this->db->order_by('id', 'DESC');
		$result = $this->db->get('tbl_student');
		$result = $result->result();
		if (!empty($result)) {

			foreach ($result as $result_result) {

				$activity[] = array(

					'title'				=> 'Refund Admission',

					'created_on' 		=> $result_result->created_on,

					'description' 		=> $admission->student_name . ' has refund Admission',

					'remark' 			=> '',

					'single_file' 		=> '',

					'multiple_files'	=> '',
					'link'				=> '',
					'edit_status'		=> '0',
					'id'				=> '0',
					'file'				=> '',
				);
			}
		}




		usort($activity, $this->sortByDate('created_on'));

		return $activity;
	}

	function sortByDate($key)
	{

		return function ($a, $b) use ($key) {

			$t1 = strtotime($a[$key]);

			$t2 = strtotime($b[$key]);

			return $t2 - $t1;
		};
	}

	function date_compare($element1, $element2)
	{

		$datetime1 = strtotime($element1['created_on']);

		$datetime2 = strtotime($element2['created_on']);

		return $datetime1 - $datetime2;
	}
	public function get_remark_activity_data()
	{
		$this->db->where('id', $this->input->post('id'));
		$result = $this->db->get('tbl_student_remarks');
		echo json_encode($result->row());
	}
	public function set_student_special_remark($file)
	{

		$data = array(

			'student_id' 	=> $this->input->post('student_id'),

			'remark' 		=> $this->input->post('remark'),

			'file' 			=> $file,

			'added_by' 		=> $this->session->userdata('admin_id'),

			'created_on'	=> date("Y-m-d H:i:s")

		);

		$this->db->insert('tbl_student_remarks', $data);

		return true;
	}
	public function set_student_special_remark_common($data)
	{
		$this->db->insert('tbl_student_remarks', $data);

		return true;
	}

	public function update_activity_remark($file)
	{
		$data = array(
			'remark' 		=> $this->input->post('edit_remark'),
			'file' 			=> $file,
			'added_by' 		=> $this->session->userdata('admin_id'),
		);
		$this->db->where('id', $this->input->post('edit_id'));
		$this->db->update('tbl_student_remarks', $data);
		return true;
	}

	public function get_student_details($number)
	{

		$this->db->select('tbl_student.*,tbl_center.center_name');

		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id');

		$this->db->where('tbl_student.enrollment_number', $number);

		$this->db->where('tbl_student.is_deleted', '0');

		$this->db->where('tbl_student.status', '1');

		$result = $this->db->get('tbl_student')->row();

		return $result;
	}

	public function get_student_last_exam($id)
	{

		$this->db->where('student_id', $id);
		$this->db->where('is_deleted', '0');
		$this->db->order_by('year_sem', 'DESC');

		$this->db->limit(1);

		$result = $this->db->get('tbl_exam_results')->row();

		if (!empty($result)) {

			return $result->examination_month . ' - ' . $result->examination_year;
		} else {
			return '-';
		}
	}

	public function get_update_pci()
	{

		$data = array(

			'pci' => $this->input->post('pci'),

		);

		$this->db->where('id', $this->input->post('student'));

		$this->db->update('tbl_student', $data);
	}
	public function set_student_reply_feedback()
	{
		$data = array(
			'reply' 		=> $this->input->post('reply'),
			'replied_by' 	=> $this->session->userdata('admin_id'),
		);
		$this->db->where('id', $this->input->post('id'));
		$this->db->update('tbl_student_feedback', $data);
		return true;
	}

	public function get_admission_unique_email()
	{
		$this->db->where('email', $this->input->post('email'));
		if ($this->input->post('id') != "") {
			$this->db->where('id !=', $this->input->post('id'));
		}
		$this->db->where('is_deleted', '0');
		$result = $this->db->get('tbl_student');
		echo $result->num_rows();
	}


	public function get_all_passout_student_list_ajax($length, $start, $search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.admission_status', '4');

		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);

			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.id', 'DESC');
		$this->db->limit($length, $start);

		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->result();
	}
	public function get_all_passout_student_list_ajax_count($search)
	{
		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.admission_status', '4');

		if ($search != "") {
			$this->db->group_start();
			$this->db->or_like('tbl_student.enrollment_number', $search);
			$this->db->or_like('tbl_student.student_name', $search);
			$this->db->or_like('tbl_student.father_name', $search);
			$this->db->or_like('tbl_student.mother_name', $search);
			$this->db->or_like('tbl_student.mobile', $search);
			$this->db->or_like('tbl_student.email', $search);
			$this->db->or_like('tbl_id_management.id_name', $search);
			$this->db->or_like('tbl_student.id_number', $search);
			$this->db->or_like('tbl_student.gender', $search);
			$this->db->or_like('tbl_student.category', $search);
			$this->db->or_like('tbl_student.address', $search);
			$this->db->or_like('tbl_student.nationality', $search);
			$this->db->or_like('countries.name', $search);
			$this->db->or_like('states.name', $search);
			$this->db->or_like('cities.name', $search);
			$this->db->or_like('tbl_student.pincode', $search);
			$this->db->or_like('tbl_session.session_name', $search);
			$this->db->or_like('tbl_faculty.faculty_name', $search);
			$this->db->or_like('tbl_course_type.course_type', $search);
			$this->db->or_like('tbl_course.course_name', $search);
			$this->db->or_like('tbl_stream.stream_name', $search);
			$this->db->group_end();
		}
		$this->db->order_by('tbl_student.id', 'DESC');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$result = $this->db->get('tbl_student');
		return $result->num_rows();
	}


	public function get_passout_admission_form()
	{

		$this->db->select('tbl_student.*,tbl_id_management.id_name,countries.name as country_name,states.name as state_name,cities.name as city_name,tbl_session.session_name,tbl_faculty.faculty_name,tbl_course.course_name,tbl_course.print_name,tbl_stream.stream_name,tbl_course_type.course_type as course_type_name');
		$this->db->where('tbl_student.is_deleted', '0');
		$this->db->where('tbl_student.id', base64_decode($this->uri->segment(2)));
		// $this->db->where('tbl_student_fees.payment_status','0');
		$this->db->join('tbl_course_type', 'tbl_course_type.id = tbl_student.course_type', 'left');
		$this->db->join('tbl_course', 'tbl_course.id = tbl_student.course_id', 'left');
		$this->db->join('tbl_stream', 'tbl_stream.id = tbl_student.stream_id', 'left');
		$this->db->join('tbl_faculty', 'tbl_faculty.id = tbl_student.faculty_id', 'left');
		$this->db->join('tbl_session', 'tbl_session.id = tbl_student.session_id', 'left');
		$this->db->join('tbl_id_management', 'tbl_id_management.id = tbl_student.id_type', 'left');
		$this->db->join('tbl_center', 'tbl_center.id = tbl_student.center_id', 'left');
		$this->db->join('countries', 'countries.id = tbl_student.country', 'left');
		$this->db->join('states', 'states.id = tbl_student.state', 'left');
		$this->db->join('cities', 'cities.id = tbl_student.city', 'left');
		$this->db->join('tbl_student_fees', 'tbl_student_fees.id = tbl_student.id', 'left');
		$result = $this->db->get('tbl_student');
		return $result->row();
	}

	public function update_document_status()
	{
		$data = array(
			'center_verification_status' => $this->input->post('center_verification_status'),
			'center_verifed_remark' 	 => $this->input->post('center_verifed_remark'),
		);
		$this->db->where('id', $this->input->post('student_id'));
		$this->db->update('tbl_student', $data);
		return true;
	}


	public function update_qualification_data($secondary_marksheet, $sr_secondary_marksheet, $graduation_marksheet, $post_graduation_marksheet, $other_qualification_marksheet)
	{
		if ($secondary_marksheet == '') {
			$secondary_marksheet = $this->input->post('secondary_marksheet_old');
		}
		if ($sr_secondary_marksheet == '') {
			$sr_secondary_marksheet = $this->input->post('sr_secondary_marksheet_old');
		}
		if ($graduation_marksheet == '') {
			$graduation_marksheet = $this->input->post('graduation_marksheet_old');
		}
		if ($post_graduation_marksheet == '') {
			$post_graduation_marksheet = $this->input->post('post_graduation_marksheet_old');
		}
		if ($other_qualification_marksheet == '') {
			$other_qualification_marksheet = $this->input->post('other_qualification_marksheet_old');
		}
		$data = array(
			'student_id' 						=> $this->input->post('student_id'),
			'secondary_year' 					=> $this->input->post('secondary_year'),
			'secondary_university' 				=> $this->input->post('secondary_university'),
			'secondary_marks' 					=> $this->input->post('secondary_marks'),
			'secondary_marksheet' 				=> $secondary_marksheet,
			'sr_secondary_year' 				=> $this->input->post('sr_secondary_year'),
			'sr_secondary_university' 			=> $this->input->post('sr_secondary_university'),
			'sr_secondary_marks' 				=> $this->input->post('sr_secondary_marks'),
			'sr_secondary_marksheet' 			=> $sr_secondary_marksheet,
			'graduation_year' 					=> $this->input->post('graduation_year'),
			'graduation_university' 			=> $this->input->post('graduation_university'),
			'graduation_marks' 					=> $this->input->post('graduation_marks'),
			'graduation_marksheet' 				=> $graduation_marksheet,
			'post_graduation_year' 				=> $this->input->post('post_graduation_year'),
			'post_graduation_university' 		=> $this->input->post('post_graduation_university'),
			'post_graduation_marks' 			=> $this->input->post('post_graduation_marks'),
			'post_graduation_marksheet' 		=> $post_graduation_marksheet,
			'other_qualification_year' 			=> $this->input->post('other_qualification_year'),
			'other_qualification_university' 	=> $this->input->post('other_qualification_university'),
			'other_qualification_marks' 		=> $this->input->post('other_qualification_marks'),
			'other_qualification_marksheet' 	=> $other_qualification_marksheet,
		);
		if ($this->input->post('qualification_id') == "") {
			$date = array(
				'created_on'		=> date("Y-m-d H:i:s"),
			);
			$newArray = array_merge($data, $date);
			$this->db->insert('tbl_student_qualification', $newArray);
		} else {
			$this->db->where('id', $this->input->post('qualification_id'));
			$this->db->update('tbl_student_qualification', $data);
		}
	}

	public function get_passout_admission_qualification()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('student_id', $this->uri->segment(2));
		$result = $this->db->get('tbl_student_qualification');
		return $result->row();
	}

	public function get_rr_student($id, $year_sem)
	{
		// echo "<pre>";print_r($year_sem);exit;
		$this->db->where('tbl_re_registered_student.is_deleted', '0');
		$this->db->where('tbl_re_registered_student.student_id', $id);
		// $this->db->where('tbl_re_registered_student.current_year_sem',$year_sem); 
		$this->db->where('tbl_re_registered_student.previous_year_sem', $year_sem);
		$this->db->order_by('tbl_re_registered_student.id', 'DESC');
		$result = $this->db->get('tbl_re_registered_student');
		// return $result->row();
		$result = $result->row();
		// echo "<pre>";print_r($result);exit;

		if ($result) {
			if ($result->payment_status == 1) {
				return $result;
				// print_r($result);
			} else {
				$created_date = new DateTime($result->created_on);
				$current_date = new DateTime();
				$difference = $current_date->diff($created_date);
				$months_difference = ($difference->y * 12) + $difference->m;
				if ($months_difference <= 4) {
					return $result;
					// $result= $result;
				}
			}
		}
		// return null;
		return $result;
	}

	public function get_rr_student_examination($id, $year_sem)
	{
		$this->db->where('tbl_exam_results.is_deleted', '0');
		$this->db->where('tbl_exam_results.status', '1');
		$this->db->where('tbl_exam_results.student_id', $id);
		$this->db->where('tbl_exam_results.year_sem', $year_sem);
		$this->db->order_by('tbl_exam_results.id', 'DESC');
		$result = $this->db->get('tbl_exam_results');
		return $result->row();
	}

	public function get_fees_type($id)
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('status', '1');
		$this->db->where('id', $id);
		$result = $this->db->get('tbl_student');
		$result = $result->row();

		// echo "<pre>";print_r($result);exit;

		if (!empty($result)) {
			// $this->db->select('tbl_fees_realtion.*,tbl_course.course_name,tbl_stream.stream_name');
			// $this->db->where('tbl_fees_realtion.is_deleted', '0');
			// $this->db->where('tbl_fees_realtion.status', '1');
			// $this->db->where('tbl_fees_realtion.course_id', $result->course_id);
			// $this->db->where('tbl_fees_realtion.stream_id', $result->stream_id);
			// $this->db->join('tbl_course', 'tbl_course.id = tbl_fees_realtion.course_id');
			// $this->db->join('tbl_stream', 'tbl_stream.id = tbl_fees_realtion.stream_id');
			// $result = $this->db->get('tbl_fees_realtion');
			// return $result->row();

			$this->db->select('tbl_center_fees.*,tbl_course.course_name,tbl_stream.stream_name');
			$this->db->where('tbl_center_fees.is_deleted', '0');
			$this->db->where('tbl_center_fees.status', '1');
			$this->db->where('tbl_center_fees.course_id', $result->course_id);
			$this->db->where('tbl_center_fees.center_id', $result->center_id);
			$this->db->where('tbl_center_fees.stream_id', $result->stream_id);
			$this->db->join('tbl_course', 'tbl_course.id = tbl_center_fees.course_id');
			$this->db->join('tbl_stream', 'tbl_stream.id = tbl_center_fees.stream_id');
			$result = $this->db->get('tbl_center_fees');
			return $result->row();
		}

		return array();
	}


	public function get_degree_certificate()
	{
		$this->db->where('tbl_certificate_fees_relation.is_deleted', '0');
		$this->db->where('tbl_certificate_fees_relation.status', '1');
		$this->db->where('tbl_certificate_fees_relation.certificate_type', '2');
		$result = $this->db->get('tbl_certificate_fees_relation');
		return $result->row();
	}
}
