<?php if (! defined('BASEPATH')) exit('No direct script access allowed');
class Student_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->is_logged();

		$this->check_access();
	}
	public function is_logged()
	{
		if ($this->session->userdata('admin_id') == "") {
			redirect('erp-access');
		}
	}
	public function check_access()
	{
		$access = $this->Setting_model->get_user_privilege_link();

		if (!in_array($this->uri->segment(1), $access)) {

			//$this->session->set_flashdata('message','Sorry! You dont have access to this module!');

			//redirect(base_url());

		}
	}
	public function new_pending_student()
	{
		if ($this->input->post('save_btn') == 'reply_submit') {
			$this->Student_model->set_cancel_student_remark();

			$this->session->set_flashdata('success', 'Admission cancel successfully!');

			redirect('new_pending_student');
		}

		$this->load->view('admin/new_pending_student');
	}
	public function enrolled_new_student()
	{
		// echo "<pre>";print_r($this->input->post('validate_password'));exit;

		if ($this->input->post('validate_password') == "validate_password") {
			$result = $this->Student_model->enroll_validate_password();
			if ($result) {
				$this->session->set_flashdata('success', 'Password validated');
			} else {
				$this->session->set_flashdata('message', 'invalid password');
			}
			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->form_validation->set_rules('student_name', 'student name', 'required');

		if ($this->form_validation->run() === FALSE) {
			$data['student'] = $this->Student_model->get_student_for_enrolled();
			$data['fees'] = $this->Student_model->get_student_fees_for_enrolled();

			$data['bank'] = $this->Student_model->get_active_bank();

			$this->load->view('admin/enrolled_new_student', $data);
		} else {

			$result = $this->Student_model->generate_enrollment_number();

			$this->session->set_flashdata('success', 'Fees record updated successfully');

			redirect($_SERVER['HTTP_REFERER']);
		}
	}

	public function print_admission_form()
	{
		// echo "<pre>";print_r($_POST);exit;
		$student_id = $this->uri->segment(2);
		// echo "<pre>";print_r($this->uri->segment(2));exit;
		$data['admission'] = $this->Common_print_model->get_admission_form($student_id);
		$data['qualification'] = $this->Common_print_model->get_admission_qualification($student_id);
		$this->load->view('admin/print_admission_form', $data);
	}
	public function admin_print_id()
	{
		$student = $this->uri->segment(2);
		$data['student_profile'] = $this->Student_model->get_admission_form($student);
		$this->load->view('admin/id_card', $data);
	}

	public function admission_list()
	{

		if ($this->input->post('activate') == "activate") {

			$this->Student_model->all_activate_center_wise();

			$this->session->set_flashdata('success', 'Addmission activated successfully');

			redirect($_SERVER['HTTP_REFERER']);
		}

		if ($this->input->post('hold') == "hold") {

			$this->Student_model->all_hold_center_wise();

			$this->session->set_flashdata('success', 'Addmission hold successfully');

			redirect($_SERVER['HTTP_REFERER']);
		}

		if ($this->input->post('save_btn') == 'reply_submit') {

			$this->Student_model->set_cancel_student_remark();

			$this->session->set_flashdata('success', 'Admission cancel successfully!');

			redirect('admission_list');
		}

		$data['session'] = $this->Student_model->get_all_session_list();

		$data["centers"] = $this->Admin_model->get_center_data_for_dropdown();

		$this->load->view('admin/admission_list', $data);
	}
	public function student_activity()
	{
		if ($this->input->post('update_remark') == "update_remark") {
			if (!empty($_FILES["userfile"]['name'][0]) && $_FILES["userfile"]['name'][0] != "") {
				$fileName = $this->Digitalocean_model->upload_photo_multiple($filename = "userfile", $path = "student_remark_document/");
			} else {
				$fileName = $this->input->post('edit_file');
			}
			$this->Student_model->update_activity_remark($fileName);
			$this->session->set_flashdata('success', 'Remark updated successfully!');
			redirect($_SERVER['HTTP_REFERER']);
		}
		$this->form_validation->set_rules('remark', 'remark', 'required');
		if ($this->form_validation->run() === FALSE) {
			$data['activity'] = $this->Student_model->get_student_all_activities();
			// echo "<pre>";print_r($data['activity']);exit;
			$data['student'] = $this->Student_model->get_single_student();

			$this->load->view('admin/student_activity', $data);
		} else {

			$fileName = $this->Digitalocean_model->upload_photo_multiple($filename = "userfile", $path = "student_remark_document/");

			$this->Student_model->set_student_special_remark($fileName);

			$this->session->set_flashdata('success', 'Remark added successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}
	}

	public function new_admission()
	{

		$this->load->view('admin/new_admission');
	}

	public function search_student()
	{

		$this->load->view('admin/search_student');
	}

	public function today_admission()
	{

		$this->load->view('admin/today_admission');
	}

	public function approved_admission()
	{

		$this->Student_model->approved_admission();

		$this->session->set_flashdata('success', 'Admission approved successfully!');

		redirect('new_admission');
	}

	public function update_student()
	{

		$this->form_validation->set_rules('student_name', 'student name', 'required');

		$this->form_validation->set_rules('student_id', 'student name', 'required');

		if ($this->form_validation->run() === FALSE) {

			$data['student'] = $this->Student_model->get_single_student();

			// echo "<pre>";print_r($data['student']);exit;

			$data['course'] = $this->Course_model->get_all_course_stream_relation();

			$data['country'] = $this->Web_model->get_all_country();

			$data['qualification'] = $this->Student_model->get_single_qualification();

			$data['session'] = $this->Student_model->get_all_session();

			$data["centers"] = $this->Separate_student_model->get_all_centers();

			$this->load->view('admin/update_student', $data);
		} else {

			$identity_softcopy = '';

			if ($_FILES['identity_softcopy']['name'] != "") {

				$identity_softcopy = $this->Digitalocean_model->upload_photo($filename = "identity_softcopy", $path = "images/student_identity_softcopy/");
			}

			$photo = '';

			if ($_FILES['photo']['name'] != "") {

				$photo = $this->Digitalocean_model->upload_photo($filename = "photo", $path = "images/profile_pic/");

				/*$tmp = explode('.', $_FILES['photo']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/profile_pic/",

					'allowed_types' => "jpg|jpeg|png",

					'file_name'		=> $this->input->post('student_id')."-sin".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('photo')){

					$data = $this->upload->data();				

					$photo = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}



			$ohter_files = '';

			if ($_FILES['ohter_files']['name'] != "") {

				$ohter_files = $this->Digitalocean_model->upload_photo($filename = "ohter_files", $path = "images/student_identity_softcopy/");
			}

			$photo = '';

			if ($_FILES['photo']['name'] != "") {

				$photo = $this->Digitalocean_model->upload_photo($filename = "photo", $path = "images/profile_pic/");

				/*$tmp = explode('.', $_FILES['photo']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/profile_pic/",

					'allowed_types' => "jpg|jpeg|png",

					'file_name'		=> $this->input->post('student_id')."-sin".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('photo')){

					$data = $this->upload->data();				

					$photo = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$signature = '';

			if ($_FILES['signature']['name'] != "") {

				$signature = $this->Digitalocean_model->upload_photo($filename = "signature", $path = "images/signature/");

				/*$tmp = explode('.', $_FILES['signature']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/signature/",

					'allowed_types' => "*",

					'file_name'		=> $this->input->post('student_id')."-sin".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('signature')){

					$data = $this->upload->data();				

					$signature = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$noc = "";

			if ($_FILES['noc']['name'] != "") {

				$noc = $this->Digitalocean_model->upload_photo($filename = "noc", $path = "images/noc/");

				/*$config = array(

						'upload_path' 	=> "images/noc/",

						'allowed_types' => "*",

						'encrypt_name' => TRUE,

					);			

					$this->upload->initialize($config);

					if($this->upload->do_upload('noc')){

						$data = $this->upload->data();				

						$noc = $data['file_name'];	

					}*/
			}

			$permission_letter = "";

			if ($_FILES['permission_letter']['name'] != "") {

				$permission_letter = $this->Digitalocean_model->upload_photo($filename = "permission_letter", $path = "images/permission_letter/");

				/*$config = array(

						'upload_path' 	=> "images/noc/",

						'allowed_types' => "*",

						'encrypt_name' => TRUE,

					);			

					$this->upload->initialize($config);

					if($this->upload->do_upload('noc')){

						$data = $this->upload->data();				

						$noc = $data['file_name'];	

					}*/
			}

			//echo $signature;exit;

			$secondary_marksheet = '';

			if ($_FILES['secondary_marksheet']['name'] != "") {

				$secondary_marksheet = $this->Digitalocean_model->upload_photo($filename = "secondary_marksheet", $path = "images/qualification/");

				/*$tmp = explode('.', $_FILES['secondary_marksheet']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/qualification",

					'allowed_types' => "*",

					'file_name'		=> $this->input->post('student_id')."-secondary".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('secondary_marksheet')){

					$data = $this->upload->data();				

					$secondary_marksheet = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$sr_secondary_marksheet = '';

			if ($_FILES['sr_secondary_marksheet']['name'] != "") {

				$sr_secondary_marksheet = $this->Digitalocean_model->upload_photo($filename = "sr_secondary_marksheet", $path = "images/qualification/");

				/*$tmp = explode('.', $_FILES['sr_secondary_marksheet']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/qualification",

					'allowed_types' => "*",

					'file_name'	=> $this->input->post('student_id')."-sr_secondary".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('sr_secondary_marksheet')){

					$data = $this->upload->data();				

					$sr_secondary_marksheet = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$graduation_marksheet = '';

			if ($_FILES['graduation_marksheet']['name'] != "") {

				$graduation_marksheet = $this->Digitalocean_model->upload_photo($filename = "graduation_marksheet", $path = "images/qualification/");

				/*

				$tmp = explode('.', $_FILES['graduation_marksheet']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/qualification",

					'allowed_types' => "*",

					'file_name'	=> $this->input->post('student_id')."-graduation".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('graduation_marksheet')){

					$data = $this->upload->data();				

					$graduation_marksheet = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$post_graduation_marksheet = '';

			if ($_FILES['post_graduation_marksheet']['name'] != "") {

				$post_graduation_marksheet = $this->Digitalocean_model->upload_photo($filename = "post_graduation_marksheet", $path = "images/qualification/");

				/*$tmp = explode('.', $_FILES['post_graduation_marksheet']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/qualification",

					'allowed_types' => "*",

					'file_name'	=> $this->input->post('student_id')."-pg".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('post_graduation_marksheet')){

					$data = $this->upload->data();				

					$post_graduation_marksheet = $data['file_name'];	

				}else{ 

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$other_qualification_marksheet = '';

			if ($_FILES['other_qualification_marksheet']['name'] != "") {

				$other_qualification_marksheet = $this->Digitalocean_model->upload_photo($filename = "other_qualification_marksheet", $path = "images/qualification/");

				/*

				$tmp = explode('.', $_FILES['other_qualification_marksheet']['name']);

				$ext = end($tmp);

				$config = array(

					'upload_path' 	=> "images/qualification",

					'allowed_types' => "*",

					'file_name'	=> $this->input->post('student_id')."-oth".".".$ext,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('other_qualification_marksheet')){

					$data = $this->upload->data();				

					$other_qualification_marksheet = $data['file_name'];	

				}else{ echo $this->upload->display_errors();exit;

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$undertaking = "";

			if ($_FILES['undertaking']['name'] != "") {

				$undertaking = $this->Digitalocean_model->upload_photo($filename = "undertaking", $path = "images/permission_letter/");

				/*$config = array(

					'upload_path' 	=> "images/noc/",

					'allowed_types' => "*",

					'encrypt_name' => TRUE,

				);			

				$this->upload->initialize($config);

				if($this->upload->do_upload('noc')){

					$data = $this->upload->data();				

					$noc = $data['file_name'];	

				}else{ 

					$noc = "";

				}*/
			}

			$result = $this->Student_model->update_student($identity_softcopy, $photo, $noc, $signature, $secondary_marksheet, $sr_secondary_marksheet, $graduation_marksheet, $post_graduation_marksheet, $other_qualification_marksheet, $permission_letter, $ohter_files, $undertaking);

			$this->session->set_flashdata('success', 'Student updated successfully!');

			// redirect('new_pending_student');
			redirect('admission_list');
		}
	}

	public function manage_student_account()
	{
		$this->form_validation->set_rules('student_id', 'student name', 'required');
		if ($this->form_validation->run() === FALSE) {
			$data['student'] = $this->Student_model->get_single_student();
			$data['bank'] = $this->Setting_model->get_all_bank_list();
			$data['payment'] = $this->Student_model->get_all_student_fees();
			$data['single'] = $this->Student_model->get_single_student_fees();
			$data['single_lateral_fee'] = $this->Student_model->get_single_lateral_student_fees();
			$data['single_registration_fee'] = $this->Student_model->get_single_registration_fees($data['student']->center_id, $data['student']->course_id, $data['student']->stream_id);
			$data['paid_amt'] = $this->Student_model->get_student_paid_addmission_fees();
			$data['exam_amt'] = $this->Student_model->get_student_paid_exam_fees();
			// $data['lateral_amt'] = $this->Student_model->get_student_lateral_fees();
			$data['fees'] = $this->Student_model->get_fees_type($this->uri->segment(2));
			$data['degree'] = $this->Student_model->get_degree_certificate();
			$this->load->view('admin/manage_student_account', $data);
		} else {
			$result = $this->Student_model->update_student_account();
			$this->session->set_flashdata('success', 'Account updated successfully!');
			redirect('manage_student_account/' . $this->input->post('student_id'));
		}
	}

	public function student_qualification()
	{
		$data['student'] = $this->Student_model->get_single_student();
		$data['qualification'] = $this->Student_model->get_admission_qualification();
		$this->load->view('admin/student_qualification', $data);
	}

	public function otp_lead()
	{

		$this->load->view('admin/otp_lead');
	}

	public function enquiry_list()
	{

		$this->load->view('admin/enquiry_list');
	}

	public function pulp_enquiry_list()
	{

		$this->load->view('admin/pulp_enquiry_list');
	}

	public function admin_campus_enquiry()
	{

		$this->load->view('admin/admin_campus_enquiry');
	}



	public function successfull_phd_registration()
	{

		$this->load->view('admin/successfull_phd_registration');
	}

	public function failed_phd_registration()
	{

		$this->load->view('admin/failed_phd_registration');
	}
	public function edit_phd_registration_payment()
	{
		$this->form_validation->set_rules('student_name', 'student name', 'required');
		if ($this->form_validation->run() === FALSE) {
			$data['single'] = $this->Student_model->get_failed_phd_single();
			$data['center'] = $this->Student_model->get_center_list();
			$this->load->view('admin/edit_phd_registration_payment', $data);
		} else {
			$result = $this->Student_model->set_update_phd_payment();
			$this->session->set_flashdata('success', 'Payment updated successfully!');
			redirect('successfull_phd_registration');
		}
	}
	public function view_phd_registration_payment()
	{

		$data['student'] = $this->Student_model->get_failed_phd_single();

		$this->load->view('admin/view_phd_registration_payment', $data);
	}

	public function phd_exams_student()
	{
		$data['student'] = $this->Student_model->get_phd_exam_student();
		$this->load->view('admin/phd_exams_student', $data);
	}
	public function student_feedback_list()
	{
		$this->form_validation->set_rules('reply', 'reply', 'required');
		if ($this->form_validation->run() === FALSE) {
			$this->load->view('admin/student_feedback_list');
		} else {
			$this->Student_model->set_student_reply_feedback();
			$this->session->set_flashdata('success', 'replyied successfully!');
			redirect('student_feedback_list');
		}
	}
	public function replied_student_feedback_list()
	{
		$this->form_validation->set_rules('reply', 'reply', 'required');
		if ($this->form_validation->run() === FALSE) {
			$this->load->view('admin/replied_student_feedback_list');
		} else {
			$this->Student_model->set_student_reply_feedback();
			$this->session->set_flashdata('success', 'replyied successfully!');
			redirect('replied_student_feedback_list');
		}
	}
	public function phd_exam_student_ans_book()
	{
		$data['student_ans_book_test_name'] = $this->Student_model->get_phd_exam_student_ans_book_test_name();
		// echo "<pre>";print_r($data['student_ans_book_test_name']);exit;
		$this->load->view('admin/phd_exam_student_ans_book', $data);
	}

	public function send_phd_result_mail()
	{
		$this->Student_model->send_phd_result_mail();

		$this->session->set_flashdata('success', 'Mail sent successfully!');

		redirect($_SERVER['HTTP_REFERER']);
	}



	public function re_registered_student_success()
	{
		$this->load->view("admin/re_registered_student_success");
	}



	public function re_registered_student_fail()
	{
		$this->load->view("admin/re_registered_student_success");
	}


	public function passout_student_list()
	{
		$this->load->view("admin/passout_student_list");
	}



	public function student_re_registration_edit()
	{
		$this->form_validation->set_rules("bank", "bank", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['bank'] = $this->Student_model->get_active_bank();

			$data["stu_data"] = $this->Student_model->get_failed_re_registered_student($this->uri->segment(3));

			//echo "<pre>";

			//print_r($data);exit;

			$this->load->view("admin/student_re_registration_edit", $data);
		} else {

			$this->Student_model->student_re_registration_edit();

			$this->session->set_flashdata('success', 'Payment updated successfully!');

			redirect("re-registered-student-success");
		}
	}



	public function pendding_reregistration_student_list()
	{

		$this->load->view("admin/pendding_reregistration_student_list");
	}

	public function cancel_admission_list()
	{

		$this->load->view("admin/cancel_admission_list");
	}

	public function hold_admission_list()
	{

		$this->load->view("admin/hold_admission_list");
	}

	public function new_thesis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_thesis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/new_thesis_list");
	}

	public function complete_thesis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_thesis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/complete_thesis_list");
	}

	public function rejected_thesis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_thesis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/rejected_thesis_list");
	}

	public function update_thesis()
	{

		$this->form_validation->set_rules("thesis_title", "thesis title", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single'] = $this->Student_model->get_single_thesis();

			$data['guide'] = $this->Student_model->get_active_guide_list();

			$this->load->view("admin/update_thesis", $data);
		} else {

			$file1 = '';

			if (isset($_FILES['file1'])) {

				$file1 = $this->Digitalocean_model->upload_photo($filename = "file1", $path = "images/thesis/");

				/*

				$config = array(

					'upload_path' 	=> "images/thesis",

					'allowed_types' => "*",

					'encrypt_name'	=> true,

				);

				$this->upload->initialize($config);

				if($this->upload->do_upload('userfile2')){

					$data = $this->upload->data();	

					$file1 = $data['file_name'];

				}else{

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$res = $this->Student_model->get_update_thesis($file1);

			if ($res == 1) {

				$this->session->set_flashdata('sucess', 'Data updated successfully!!');
			}

			redirect('new_thesis_list');
		}
	}

	public function new_synopsis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_synopsis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/new_synopsis_list");
	}

	public function complete_synopsis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_synopsis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/complete_synopsis_list");
	}

	public function rejected_synopsis_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_synopsis();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/rejected_synopsis_list");
	}

	public function update_synopsis()
	{

		$this->form_validation->set_rules("thesis_title", "thesis title", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single_synopsis'] = $this->Student_model->get_single_synopsis();

			$data['guide_list'] = $this->Student_model->get_active_guide_synopsis_list();

			$data['signature'] = $this->Setting_model->get_all_signature();

			$this->load->view("admin/update_synopsis", $data);
		} else {

			$file1 = '';

			if (isset($_FILES['userfile1'])) {

				$file1 = $this->Digitalocean_model->upload_photo($filename = "userfile1", $path = "images/thesis/");

				/*$config = array(

					'upload_path' 	=> "images/thesis",

					'allowed_types' => "*",

					'encrypt_name'	=> true,

				);

				$this->upload->initialize($config);

				if($this->upload->do_upload('userfile1')){

					$data = $this->upload->data();	

					$file1 = $data['file_name'];

				}else{

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$res = $this->Student_model->get_update_synopsis($file1);

			if ($res == 1) {

				$this->session->set_flashdata('sucess', 'Data updated successfully!!');
			}

			redirect('new_synopsis_list');
		}
	}

	public function abstract_report_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_abstract();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/abstract_report_list");
	}

	public function rejected_abstract_report_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_abstract();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/rejected_abstract_report_list");
	}

	public function approved_abstract_report_list()
	{

		if ($this->input->post('reject') == "reject") {

			$this->Student_model->set_reject_abstract();

			$this->session->set_flashdata('success', 'Record rejected successfully!');

			redirect($_SERVER['HTTP_REFERER']);
		}

		$this->load->view("admin/approved_abstract_report_list");
	}

	public function update_abstract_report()
	{

		$this->form_validation->set_rules("report_status", "report status", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single'] = $this->Student_model->get_single_abstract_report();

			$this->load->view("admin/update_abstract_report", $data);
		} else {

			$userfile1 = '';

			if (isset($_FILES['userfile1']) && $_FILES['userfile1']['name'] != "") {

				$userfile1 = $this->Digitalocean_model->upload_photo($filename = "userfile1", $path = "images/abstract/");

				/*$config = array(

					'upload_path' 	=> "images/thesis",

					'allowed_types' => "*",

					'encrypt_name'	=> true,

				);

				$this->upload->initialize($config);

				if($this->upload->do_upload('userfile1')){

					$data = $this->upload->data();	

					$file1 = $data['file_name'];

				}else{

					$error = array('error' => $this->upload->display_errors());	

					$this->upload->display_errors();

				}*/
			}

			$res = $this->Student_model->get_update_abstract($userfile1);

			if ($res == 1) {

				$this->session->set_flashdata('sucess', 'Data updated successfully!!');
			}

			redirect('abstract_report_list');
		}
	}

	public function progress_report_list()
	{

		$this->load->view("admin/progress_report_list");
	}

	public function hold_login()
	{

		$this->Student_model->hold_login();

		$this->session->set_flashdata('success', 'Record update successfully');

		redirect($_SERVER['HTTP_REFERER']);
	}

	public function activate_login()
	{

		$this->Student_model->activate_login();

		$this->session->set_flashdata('success', 'Record update successfully');

		redirect($_SERVER['HTTP_REFERER']);
	}

	public function hold_login_single()
	{

		$this->Student_model->hold_login_single();

		$this->session->set_flashdata('success', 'Record update successfully');

		redirect($_SERVER['HTTP_REFERER']);
	}

	public function activate_login_single()
	{

		$this->Student_model->activate_login_single();

		$this->session->set_flashdata('success', 'Record update successfully');

		redirect($_SERVER['HTTP_REFERER']);
	}

	public function pending_student_remark()
	{

		$this->Student_model->pending_student_remark();

		$this->session->set_flashdata('success', 'Record update successfully');

		redirect($_SERVER['HTTP_REFERER']);
	}

	public function enquiry_head()
	{

		$this->form_validation->set_rules("head_name", "head name", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single'] = $this->Student_model->get_single_followup_head();

			$this->load->view("admin/enquiry_head", $data);
		} else {

			$result = $this->Student_model->set_enquiry_head();

			if ($result == 1) {

				$this->session->set_flashdata('sucess', 'Head updated successfully!!');
			} else {

				$this->session->set_flashdata('sucess', 'Head added successfully!!');
			}

			redirect('enquiry_head');
		}
	}

	public function pulp_admission_list()
	{

		$this->load->view('admin/pulp_admission_list');
	}

	public function add_refund()
	{

		$this->form_validation->set_rules("account_number", "Account number", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single'] = $this->Student_model->get_single_refund();

			$this->load->view("admin/add_refund", $data);
		} else {

			$result = $this->Student_model->set_refund();

			if ($result == 1) {

				$this->session->set_flashdata('sucess', 'Refund updated successfully!!');
			} else {

				$this->session->set_flashdata('sucess', 'Refund added successfully!!');
			}

			redirect('refunded_student_list');
		}
	}

	public function refunded_student_list()
	{

		$this->load->view('admin/refunded_student_list');
	}

	public function add_refund_research()
	{

		$this->form_validation->set_rules("account_number", "Account number", "required");

		if ($this->form_validation->run() === FALSE) {

			$data['single'] = $this->Student_model->get_single_refund_research();
			// echo "<pre>";print_r($data['single']);exit;
			$data['name_success'] = $this->Student_model->get_all_phd_registration();
			$data['name_failed'] = $this->Student_model->get_all_phd_registration_refund();
			$data['payment_refund'] = $this->Student_model->get_all_phd_registration_student_refunded();




			$this->load->view("admin/add_refund_research", $data);
		} else {

			$result = $this->Student_model->set_refund_refresh();

			if ($result == 1) {

				$this->session->set_flashdata('sucess', 'Refund updated successfully!!');
			} else {

				$this->session->set_flashdata('sucess', 'Refund added successfully!!');
			}

			redirect('refunded_phd_registration');
		}
	}

	public function refunded_phd_registration()
	{

		$this->load->view('admin/refunded_phd_registration');
	}

	public function admin_set_reregistration_form()
	{
		if ($this->input->post('next') == "next") {
			$this->Student_model->get_verified_student();
		}
		$this->form_validation->set_rules("id", "student", "required");

		if ($this->form_validation->run() === FALSE) {
			$data['student'] = $this->Student_model->get_student_for_rr();
			if (!empty($data['student'])) {
				$stu_rr_exam_check = $this->Student_model->get_rr_student_examination($data['student']->id, $data['student']->year_sem);
				$stu_rr_check = $this->Student_model->get_rr_student($data['student']->id, $data['student']->year_sem);

				if (empty($stu_rr_exam_check)) {
					$this->session->set_flashdata('message', 'Your Result Not Generated');
					redirect('admin_set_reregistration_form');
				} else {
					if (!empty($stu_rr_check)) {
						$this->session->set_flashdata('message', 'You have already Filled Re-registration form');
						redirect('admin_set_reregistration_form');
					} else {
						// $this->session->set_flashdata('message','You have entered wrong enrollment number');
						$this->load->view("admin/admin_set_reregistration_form", $data);
					}
				}
			} else {
				$this->load->view("admin/admin_set_reregistration_form", $data);
			}
		} else {
			$stu = $this->Web_model->get_single_student_details($this->input->post("id"));
			$fees = $this->Web_model->get_student_fees($stu->course_id, $stu->stream_id, $stu->session_id, $stu->country);
			if ($stu->course_mode == 2) {
				if ($this->input->post("year_sem") % 2 == 0) {
					$this->Student_model->set_re_registration();
					$this->session->set_flashdata('success', 'Re registration form submitted successfull!');
					redirect('admin_set_reregistration_form');
				}
			}
			$student_re_registration_id = $this->Web_model->set_re_registered_student($stu->id, $fees);

			$payment_id = $this->Web_model->student_reregistration_payment_process($stu->id, $fees, $this->input->post("year_sem"));

			$this->session->set_flashdata('success', 'Re registration form submitted successfull!');

			redirect('admin_set_reregistration_form');
		}
	}



	public function print_synopsis_letter()
	{

		$data['single'] = $this->Admin_model->get_candidate_info();

		$this->load->view('admin/print_synopsis_letter', $data);
	}

	public function print_id()
	{
		$data['student_profile'] = $this->Student_model->get_passout_admission_form();
		$this->load->view('admin/id_card', $data);
	}


	public function passout_student_qualification()
	{
		if ($this->input->post('verify') == "Verify") {
			$this->Student_model->update_document_status();
			$this->session->set_flashdata('success', 'Status updated successfully');
			redirect($_SERVER['HTTP_REFERER']);
		}
		$this->form_validation->set_rules('secondary_year', 'Secondary year', 'required');
		if ($this->form_validation->run() === FALSE) {
			$data['student'] = $this->Student_model->get_passout_admission_form();
			$data['qualification'] = $this->Student_model->get_passout_admission_qualification();
			$this->load->view('admin/student_qualification', $data);
		} else {
			$secondary_marksheet = '';
			if (isset($_FILES['secondary_marksheet']) && $_FILES['secondary_marksheet']['name'] != "") {
				$secondary_marksheet = $this->Digitalocean_model->upload_photo($filename = "secondary_marksheet", $path = "images/qualification/");
			}
			$sr_secondary_marksheet = '';
			if (isset($_FILES['sr_secondary_marksheet']) && $_FILES['sr_secondary_marksheet']['name'] != "") {
				$sr_secondary_marksheet = $this->Digitalocean_model->upload_photo($filename = "sr_secondary_marksheet", $path = "images/qualification/");
			}
			$graduation_marksheet = '';
			if (isset($_FILES['graduation_marksheet']) && $_FILES['graduation_marksheet']['name'] != "") {
				$graduation_marksheet = $this->Digitalocean_model->upload_photo($filename = "graduation_marksheet", $path = "images/qualification/");
			}
			$post_graduation_marksheet = '';
			if (isset($_FILES['post_graduation_marksheet']) && $_FILES['post_graduation_marksheet']['name'] != "") {
				$post_graduation_marksheet = $this->Digitalocean_model->upload_photo($filename = "post_graduation_marksheet", $path = "images/qualification/");
			}
			$other_qualification_marksheet = '';
			if (isset($_FILES['other_qualification_marksheet']) && $_FILES['other_qualification_marksheet']['name'] != "") {
				$other_qualification_marksheet = $this->Digitalocean_model->upload_photo($filename = "other_qualification_marksheet", $path = "images/qualification/");
			}
			$result = $this->Student_model->update_qualification_data($secondary_marksheet, $sr_secondary_marksheet, $graduation_marksheet, $post_graduation_marksheet, $other_qualification_marksheet);
			if ($result == "0") {
				$this->session->set_flashdata('success', 'Details added successfully');
			} else {
				$this->session->set_flashdata('success', 'Details updated successfully');
			}
			redirect($_SERVER['HTTP_REFERER']);
		}
	}

	public function get_admission_qualification()
	{
		$this->db->where('is_deleted', '0');
		$this->db->where('student_id', base64_decode($this->uri->segment(2)));
		$result = $this->db->get('tbl_student_qualification');
		return $result->row();
	}
}
